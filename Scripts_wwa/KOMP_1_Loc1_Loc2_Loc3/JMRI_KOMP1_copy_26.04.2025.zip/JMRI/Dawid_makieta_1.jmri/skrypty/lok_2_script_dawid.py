import jarray
import jmri
import sys, os
# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py
sys.path.append(os.path.join(sys.path[0]))
import Kollib #Biblioteka autorskich funkcji

#Sekwencyjne przypisywanie adresów sensorą 
FirstSensorAdress = 1
NumberOfSensors = 12
SensorsList_P_0 = []
for i in range(FirstSensorAdress, FirstSensorAdress + NumberOfSensors):
    SensorsList_P_0.append(sensors.getSensor("LS"+str(i)))
print(SensorsList_P_0)

FirstTurnoutAdress = 13
NumberOfTurnouts = 2
TurnoutsList_P_0 = []
for i in range(FirstTurnoutAdress, FirstTurnoutAdress + NumberOfTurnouts):
    TurnoutsList_P_0.append(turnouts.getTurnout("LT"+str(i)))
print(TurnoutsList_P_0)