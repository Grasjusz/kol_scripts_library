import jarray
import jmri
import sys 
import os

# -*- coding: utf-8 -*-

# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py (ustawiony glowny katalog skryptow)
sys.path.append(os.path.join(sys.path[0])) #szuka biblioteczki w tym samym folderze w ktorym jest uruchamiany skrypt
import Kollib #Biblioteka autorskich funkcji

# Definiowanie poszczególnych elementów ścieżki do pliku - w celu dostosowania pod wlasne potrzeby
user_folder = "C:\\Users\\LOK_1"
jmri_folder = "JMRI"
file_name_LOK_2 = "EMERGENCY_lok_2_only_tram_end_day_initial_position.py"  # nazwa pliku do otwarcia

# Tworzenie pełnej ścieżki za pomocą os.path.join
file_path_LOK_2_emergency = os.path.join(user_folder, jmri_folder, "LOK_testing.jmri", "scripting", file_name_LOK_2)

#Sensory osobowe
LS17 = sensors.getSensor("LS17") #Czujnik 0 Lista 1 
LS18 = sensors.getSensor("LS18") #Czujnik 1 Lista 1 
LS19 = sensors.getSensor("LS19") #Czujnik 2 Lista 1 
LS20 = sensors.getSensor("LS20") #Czujnik 3 Lista 1 
LS21 = sensors.getSensor("LS21") #Czujnik 4 Lista 1 
LS22 = sensors.getSensor("LS22") #Czujnik 5 Lista 1 
#print("LOK2 Sensor osobowy: ", LS17, LS18, LS19, LS20, LS21, LS22)

#Sensory towarowe
LS23 = sensors.getSensor("LS23") #Czujnik 0 Lista 2
LS24 = sensors.getSensor("LS24") #Czujnik 1 Lista 2
LS25 = sensors.getSensor("LS25") #Czujnik 2 Lista 2
LS26 = sensors.getSensor("LS26") #Czujnik 3 Lista 2
LS27 = sensors.getSensor("LS27") #Czujnik 4 Lista 2
LS28 = sensors.getSensor("LS28") #Czujnik 5 Lista 2
LS29 = sensors.getSensor("LS29") #Czujnik 6 Lista 2
LS30 = sensors.getSensor("LS30") #Czujnik 7 Lista 2
LS31 = sensors.getSensor("LS31") #Czujnik 8 Lista 2
LS32 = sensors.getSensor("LS32") #mijanka/wahadlo 
#print("LOK2 Sensor towarowy: ", LS23, LS24, LS25, LS26, LS27, LS28, LS29, LS30, LS31, LS32)

#Zwrotnice
LT100 = turnouts.getTurnout("LT100") #Zwrotnica 1
LT101 = turnouts.getTurnout("LT101") #Zwrotnica 2
LT102 = turnouts.getTurnout("LT102") #Zwrotnica 3
LT103 = turnouts.getTurnout("LT103") #Zwrotnica 4
#print("LOK2 Zwrotnice: ", LT100, LT101, LT102, LT103)

class Lok2(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.

        # Sensor sprzezony z startup_script - uruchamiajacy makiete - pierwsze uruchomienie
        sensor_lok_2 = sensors.getSensor("IS100")
        self.waitSensorActive(sensor_lok_2)

        print("LOK2 Program wawa wilenska uruchomiony...  Czekam na sensor IS6..")

        # Uruchomienie pliku na stacje startowe
        exec(open(file_path_LOK_2_emergency).read(), globals())

        #Sensor wirtualny sprawdzający stacje poczatkowa
        self.startup_sensor_1 = sensors.getSensor("IS6")  # Pozycja startowa pociag pasazerski
        self.waitSensorActive(self.startup_sensor_1)

        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(3, False) #Pociag osobowy

    def handle(self):
        # handle() is called repeatedly until it returns false.
        print("LOK2 Program LOK2_HANDLE uruchomiony")

        while True:

            def check_stop():
                """Sensor wirtualny zatrzymujacy lub uruchamiajacy z powrotem makiete"""
                self.startup_sensor_1 = sensors.getSensor("IS6")  # Pozycja startowa pociag osobowy
                suspend_1 = self.waitSensorActive(self.startup_sensor_1)

                if suspend_1 == ACTIVE:
                    pass #kontynuuj program
                elif suspend_1 != ACTIVE:
                    print("LOK2 Pociagi zatrzymane LOK_2_wilenska")
                    Kollib.drive_vehicle(self, self.throttle1, 0, True) #zatrzymaj pociag osobowy i czekaj na zmiane sygnalu
                    print("LOK2 Pauza wlaczona..")
                return

            def turnouts_initial_positions():
                """Sprawdz czy zwrotnice sa w odpowiednim polozeniu i ustaw na pozycje startowe"""
                """#2 dla CLOSED, #4 dla THROW"""
                if LT100.getKnownState() == 2:
                    LT100.setState(4)
                    self.waitMsec(1000)
                    #("LOK2 Przestawiam zwrotnice na THROWN:", LT100, LT100.getKnownState())

                elif LT101.getKnownState() == 2:
                    LT101.setState(4)
                    self.waitMsec(1000)
                    #print("LOK2 Przestawiam zwrotnice na THROWN:", LT101, LT101.getKnownState())

                elif LT102.getKnownState() == 2:
                    LT102.setState(4)
                    self.waitMsec(1000)
                    #print("LOK2 Przestawiam zwrotnice na THROWN:", LT102, LT102.getKnownState())

                elif LT103.getKnownState() == 2:
                    LT103.setState(4)
                    self.waitMsec(1000)
                    #print("LOK2 Przestawiam zwrotnice na THROWN:", LT103, LT103.getKnownState())
                return

            """Funkcje dekoracyjne uruchamiajace pociag osobowy"""
            def startup_tram():
                self.throttle1.setF3(True)#Unieś pantografy
                self.waitMsec(1000)
                self.throttle1.setF6(True) # wlacz dzwiek silnika
                self.waitMsec(3000)
                self.throttle1.setF17(True)# Oświetlenie stacji docelowej pociagu
                self.waitMsec(100)
                self.throttle1.setF0(True)# Wlaczenie swiatel pociagu
                self.waitMsec(100)
                self.throttle1.setF18(True)# Zamykanie drzwi
                self.waitMsec(4000)
                self.throttle1.setF18(False)# Zamykanie drzwi
                self.waitMsec(2000)
                return
            
            """Funkcje dekoracyjne wylaczajaca pociag osobowy"""
            def shutdown_tram():
                self.throttle1.setF0(False)# Wylaczenie swiatel pociagu
                self.waitMsec(100)
                self.throttle1.setF3(False)# Opuść pantografy
                self.waitMsec(1000)
                self.throttle1.setF6(False) # wylacz dzwiek silnika
                self.waitMsec(3000)
            
            """Funkcje dekoracyjne zamykajace drzwi pociag osobowy"""
            def doors_tram():
                self.throttle1.setF18(True)# Zamykanie drzwi
                self.waitMsec(4000)
                self.throttle1.setF18(False)# Zamykanie drzwi
                self.waitMsec(2000)
                return

            """Jedzie do tylu - wozek napedowy z przodu"""
            def backward_tram():
                #print("STATE: ", LS17.state)
                print("LOK2 POCIAG OSOBOWY TRASA DO BUNKROW")
                self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(500)
                if LS17.state == ACTIVE:
                    #print("Czujnik zajety: ", LS17)
                    startup_tram() # funkcje dekoracyjne, uruchamianie pociagu osobowego
                    Kollib.drive_vehicle(self, self.throttle1, 0.4, False)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS18)
                    #print("Czujnik zajety: ", LS18)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS19)
                    #print("Czujnik zajety: ", LS19)
                    print("LOK2 Zatrzymanie na stacji 2 - BUNKRY TRASA DO BUNKROW")
                    Kollib.delay_stop(self, self.throttle1, LS19, 1)#stop gora stacja
                    self.waitMsec(5000)
                    doors_tram()  # funkcja dekoracyjna zamykajaca drzwi
                    self.waitMsec(3000)
                    print("LOK2 Start na stacji 2 - TRASA DO BUNKROW")
                    Kollib.drive_vehicle(self, self.throttle1, 0.4, False)
                    
                    #ustawienie predkosci i czasu bo brakuje czujnikow ktore pozwola plynnie zarzadzac dojechaniem do stacji
                    self.waitSensorActive(LS20)
                    #print("Czujnik zajety: ", LS20)
                    self.waitMsec(100)
                    Kollib.speed_change(self, self.throttle1, 0.4) # zwolnienie przed czujnikiem
                    self.waitMsec(20000)
                    Kollib.speed_change(self, self.throttle1, 0.1) # Maksymalne zwolnienie tuz przed czujnikiem koncowym
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS21)
                    #print("Czujnik zajety: ", LS21)
                    print("LOK2 Zatrzymanie na stacji 3 - TRASA DO BUNKROW")
                    self.waitMsec(100)
                    Kollib.delay_stop(self, self.throttle1, LS21, 100)
                    shutdown_tram() # funkcja dekoracyjna zamykajaca wylaczaja silnik i pantografy
                    self.waitMsec(1000)
                    print("LOK2 KONIEC PETLI, ROZPOCZYNAM NOWA LOK_2_WAWA_WILENSKA")
                    return

            """Jedzie do przodu - wozek napedowy z przodu"""
            def forward_tram():
                #print("STATE: ", LS17.state)
                print("LOK2 POCIAG OSOBOWY TRASA DO WAWA WILENSKA")
                self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(500)
                if LS21.state == ACTIVE:
                    #print("STATE1: ", LS21.state)
                    #print("Czujnik zajety: ", LS21)
                    startup_tram() # funkcje dekoracyjne, uruchamianie pociagu osobowego
                    print("LOK2 Start na stacji 3 - TRASA WAWA WILENSKA")
                    Kollib.drive_vehicle(self, self.throttle1, 0.4, True)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS20)
                    #print("Czujnik zajety: ", LS20)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS19)
                    #print("Czujnik zajety: ", LS19)
                    print("LOK2 Zatrzymanie na stacji 2 - TRASA WAWA WILENSKA")
                    Kollib.delay_stop(self, self.throttle1, LS19, 1000)#stop gora stacja
                    self.waitMsec(5000)
                    doors_tram()  # funkcja dekoracyjna zamykajaca drzwi
                    self.waitMsec(3000)
                    print("LOK2 Start na stacji 2 - TRASA WAWA WILENSKA")
                    Kollib.drive_vehicle(self, self.throttle1, 0.4, True)
                    
                    self.waitSensorActive(LS18)
                    #print("Czujnik zajety: ", LS18)
                    Kollib.speed_change(self, self.throttle1, 0.3)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS17)
                    #print("Czujnik zajety: ", LS17)
                    print("LOK2 Zatrzymanie na stacji 1 - TRASA WAWA WILENSKA")
                    self.waitMsec(100)
                    Kollib.delay_stop(self, self.throttle1, LS17, 2000)
                    self.waitMsec(10000)
                    Kollib.drive_vehicle(self, self.throttle1, 0.1, True) #rusz do przodu aby wzbudzic czujnik
                    self.waitMsec(1500)
                    Kollib.delay_stop(self, self.throttle1, LS17, 100)
                    shutdown_tram() # funkcja dekoracyjna zamykajaca wylaczaja silnik i pantografy
                    self.waitMsec(1000)
                    print("LOK2 KONIEC PETLI, ROZPOCZYNAM NOWA LOK_2_WAWA_WILENSKA")
                    return
        

            """Uruchom odpowiednia funkcje zalezna od tego na ktorym torze krancowym sie znajduje"""
            if LS17.state == ACTIVE:
                print("LOK2 Sprawdz czy pauza..")
                check_stop() #sprawdz czy pauza
                print("LOK2 Uruchamiam funkcje resetujaca zwrotnice")
                turnouts_initial_positions() # reset zwrotnic
                print("LOK2 Uruchamiam funkcje backward_tram")
                backward_tram()
            elif LS21.state == ACTIVE:
                print("LOK2 Uruchamiam funkcje resetująca zwrotnice")
                turnouts_initial_positions() #reset zwrotnic
                print("LOK2 Uruchamiam funkcje forward_tram")
                forward_tram()


Lok2().start()

