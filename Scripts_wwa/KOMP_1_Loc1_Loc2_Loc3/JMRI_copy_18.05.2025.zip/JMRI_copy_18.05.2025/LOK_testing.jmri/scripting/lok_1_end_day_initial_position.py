import jarray
import jmri
import sys
import os

# -*- coding: utf-8 -*-

# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py (ustawiony glowny katalog skryptow)
sys.path.append(os.path.join(sys.path[0])) #szuka biblioteczki w tym samym folderze w ktorym jest uruchamiany skrypt
import Kollib #Biblioteka autorskich funkcji

# Pobierz sensory startowe
startup_sensor = sensors.getSensor("IS1")  # Pozycja startowa tramwaj burza

#Sensory tramwaj burza
LS1 = sensors.getSensor("LS1") #Czujnik 0 Lista 1 
LS2 = sensors.getSensor("LS2") #Czujnik 1 Lista 1 
LS3 = sensors.getSensor("LS3") #Czujnik 2 Lista 1 
LS4 = sensors.getSensor("LS4") #Czujnik 3 Lista 1 
LS5 = sensors.getSensor("LS5") #Czujnik 4 Lista 1 
LS6 = sensors.getSensor("LS6") #Czujnik 5 Lista 1 
LS7 = sensors.getSensor("LS7") #Czujnik 6 Lista 1 
#print("LOK1 Sensor tramwaj burza: ", LS1, LS2, LS3, LS4, LS5, LS6, LS7)


class Lok1EndDay(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.
        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(10, False) #Tramwaj
        return

    def handle(self):
        # handle() is called repeatedly until it returns false.
        print("LOK1 funkcja awaryjna, ustawiam pociagi na pozycje startowe")
        self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana

        speed_global = 0.4 # Ustawiamy jedną zmienna główną prędkosc

        """Dzwiek sygnalizujacy dojazd na stacje startowa"""
        def make_noise_train():
            self.throttle1.setF1(False)  # wylacz dzwiek silnika
            self.throttle1.setF0(False)  # zgas światła
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(100)
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(100)
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(3000)
            return

        """Funkcja uruchomieniowa - awaryjny dojazd do stacji startowej jezeli pociag na niej sie nie znajduje
        co okolo sekunde uzywa sygnalu dziekowego - jezeli na niej sie znajduje - trabi 3 razy po 2 sekundy"""
        def drive_to_start_station():
            print("LOK1 Uruchamiam funkcje powrotu na stacje poczatkowe")
            self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
            self.waitMsec(1000)
            Kollib.drive_vehicle(self, self.throttle1, speed_global, True) # Rusza do przodu by wzbudzic pierwszy czujnik
            Kollib.speed_change(self, self.throttle1, 0.6)
            while LS1.state != ACTIVE:
                self.waitMsec(100)
                self.throttle1.setF0(True)  # wlacz mruganie swiatlami
                self.waitMsec(1000)
                self.throttle1.setF0(False)  # wylacz mruganie swiatlami
                self.waitMsec(100)
                if LS1.state == ACTIVE:
                    if LS2.state != ACTIVE:
                        Kollib.drive_vehicle(self, self.throttle1, 0.0,True)
                        print("LOK1 Pociag dojechal na stacje startowa - koniec petli")
                        self.waitMsec(100)
                        return
                    
        """Funkcja wywolujaca funkcje uruchomieniowe dojazdu do stacji startowych"""
        def tram_initial_station_func():
            if LS1.state != ACTIVE and LS2.state != ACTIVE:
                print("LOK1 Pociag nie na stacji startowej - uruchamiam funkcje jedz do stacji startowej")
                drive_to_start_station()
                print("LOK1 Pociag na stacji startowej - Koncze skrypt")
                make_noise_train()
                self.waitMsec(2000)
                return
            elif LS1.state == ACTIVE and LS2.state != ACTIVE:
                Kollib.drive_vehicle(self, self.throttle1, 0.0, True)
                print("LOK1 Pociag startowy STAL na stacji startowej - koniec petli")
                self.waitMsec(100)
                return
            elif LS1.state == ACTIVE and LS2.state == ACTIVE:
                print("LOK1 Pociag PRZED stacja startowa - uruchamiam funkcje jedz do stacji startowej")
                drive_to_start_station()
                print("LOK1 Pociag na stacji startowej - Koncze skrypt")
                make_noise_train()
                self.waitMsec(2000)
                return
                    
        tram_initial_station_func()
        print("LOK1 EMERGENCY Zmieniam IS1 na ACTIVE")
        self.waitMsec(500)
        startup_sensor.setState(ACTIVE) # IS1 - Tramwaj burza
        print("LOK1 EMERGENCYx2 Zmieniam IS1 na ACTIVE")
        self.waitMsec(1000)
        startup_sensor.setState(ACTIVE) # IS1 - Tramwaj burza - podwojne zastosowanie
        self.waitMsec(500)
        return 0

Lok1EndDay().start()

