(Since JMRI version 5.7.1.)

This directory can be used to hold "Plugin" files for JMRI.

Third-party developers, and, on occasion, JMRI developers, may wish to provide
a "Plugin" to enhance JMRI functionality.  One way to install such a plugin into
JMRI is to:
  1. Quit all JMRI programs.
  2. Acquire the plugin.
  3. Copy the acquired plugin to this directory.
  4. Re-start the JMRI programs that you use.
If it has been installed correctly, JMRI will now use the plugin.  Any plugins 
installed here will be available to all JMRI instances >for this user<, except 
when JMRI has a similarly-implemented function.

Any of these .jar files shall be added as the last .jar files in the CLASSPATH.

Note: Plugin files installed in this directory are only available on a "user-"
specific basis.  If a plugin is to be available to multiple Windows users using
this type of install, each Windows "user" who needs access to the plugin will
need to install the plugin in their own user-specific JMRI directory's "lib"
directory.

