import jarray
import jmri
import sys

from Bunkry import NA_STACJI_WISŁA

# Dodaj ścieżkę do katalogu, w którym znajduje się biblioteka Kollib.py
sys.path.append(r'C:\Users\LOK_1\JMRI\Krzysiek.jmri\scripting')
import Kollib  # Biblioteka autorskich funkcji

# Sekwencyjne przypisywanie adresów sensorą
FirstSensorAdress = 33
NumberOfSensors = 16
SensorsList3 = []
SensorsList3.append(0)
for i in range(FirstSensorAdress, FirstSensorAdress + NumberOfSensors):
    SensorsList3.append(sensors.getSensor("LS" + str(i)))
print(SensorsList3)

START_SIGNAL = sensors.getSensor("IS333")


FirstTurnoutAdress = 100
NumberOfTurnouts = 4
TurnoutsList2= []
TurnoutsList2.append(0)
for i in range(FirstTurnoutAdress, FirstTurnoutAdress + NumberOfTurnouts):
    TurnoutsList2.append(turnouts.getTurnout("LT" + str(i)))  # Tworzenie adresu zwrotnicy np. LT1, LT2...
  # Drukowanie listy zwrotnic do sprawdzenia

TurnoutsList2.append(turnouts.getTurnout("LT220"))
print(TurnoutsList2)
'''
Jeśli czujniki nie są ułożone w sekwencji, możesz dodać je jako Sensor1 = sensors.getSensor("LS1") lub
SensorsList3.append(sensors.getSensor("LS" + str(1))), jeśli chcesz umieścić je w liście.
Jeśli to możliwe, dopisz taki sam algorytm dla innych elementów.
Jeśli dany sensor nie znajduje się na liście sensorów w panelu "PanelPro" 
(jego wartość to None), skutkuje to wyłaczeniem watku w którym znajduje sie fukcja
odnoszaca sie do tego czujnika.
'''


class Lok3(jmri.jmrit.automat.AbstractAutomaton):
    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.
        print("LOK3 Program tramwaj wisla uruchomiony...  Czekam na sensor IS3.. ze skryptu startup..")
        self.waitMsec(6000)
        """Sensor wirtualny uruchamiajacy makiete - czekam na odpowiedz z startup_script.py"""
          # Pozycja startowa tramwaj wisla

        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(11, False) #Tramwaj
        #self.throttle2 = self.getThrottle(11, False) #Tramwaj 2
        return

    def handle(self):
        print("Wait for sensor start", self, "START_SIGNAL state:", START_SIGNAL.getKnownState())
        if START_SIGNAL.getKnownState() != 2:
            NA_STACJI_WISŁA.setKnownState(2)
            if NA_STACJI_ALEGRA.getKnownState() == 2 and NA_STACJI_KOLEJ.getKnownState() != 2 and NA_STACJI_WISŁA.getKnownState() != 2:
                sensors.getSensor("IS332").setKnownState(2)
        self.waitSensorActive([START_SIGNAL])
        sensors.getSensor("IS332").setKnownState(4)
        PRZEJAZD_STOP.setState(2)
        print(PRZEJAZD_STOP.getKnownState())
        self.throttle1.setF0(True)
        self.throttle1.setF1(True)
        self.throttle1.setF4(True)
        self.waitMsec(500)
        self.throttle1.setF4(False)
        self.waitMsec(500)
        self.waitMsec(1000)
        self.throttle1.setF1(True)
        self.waitMsec(100)
        self.throttle1.setF0(True)
        Kollib.drive_vehicle(self, self.throttle1, 0.5, True)
        self.waitMsec(100)


        Kollib.delay_stop(self, self.throttle1, SensorsList3[3], 4500)
        self.throttle1.setF2(True)
        self.waitMsec(500)
        self.throttle1.setF2(False)
        self.waitMsec(200)
        self.waitMsec(10000)
        self.throttle1.setF4(True)
        self.waitMsec(500)
        self.throttle1.setF4(False)
        self.waitMsec(500)
        PRZEJAZD_STOP.setState(4)
        Kollib.drive_vehicle(self, self.throttle1, 0.5, True)
        self.waitMsec(5000)
        PRZEJAZD_STOP.setState(2)


        Kollib.delay_stop(self, self.throttle1, SensorsList3[5], 2000)
        self.throttle1.setF2(True)
        self.waitMsec(500)
        self.throttle1.setF2(False)
        self.waitMsec(200)
        self.waitMsec(10000)
        self.throttle1.setF4(True)
        self.waitMsec(500)
        self.throttle1.setF4(False)
        self.waitMsec(500)
        Kollib.drive_vehicle(self, self.throttle1, 0.5, True)
        self.waitMsec(100)


        Kollib.delay_stop(self, self.throttle1, SensorsList3[8], 4500)
        self.throttle1.setF2(True)
        self.waitMsec(500)
        self.throttle1.setF2(False)
        self.waitMsec(5000)
        self.throttle1.setF4(True)
        self.waitMsec(500)
        self.throttle1.setF4(False)
        self.waitMsec(500)
        Kollib.drive_vehicle(self, self.throttle1, 0.5, True)
        self.waitMsec(100)

        Kollib.delay_stop(self, self.throttle1, SensorsList3[10], 0)
        self.throttle1.setF2(True)
        self.waitMsec(500)
        self.throttle1.setF2(False)
        self.waitMsec(200)
        self.waitMsec(10000)
        self.throttle1.setF4(True)
        self.waitMsec(500)
        self.throttle1.setF4(False)
        self.waitMsec(500)
        Kollib.drive_vehicle(self, self.throttle1, 0.5, False)
        self.waitMsec(100)

        Kollib.delay_stop(self, self.throttle1, SensorsList3[8], 0)
        self.throttle1.setF2(True)
        self.waitMsec(500)
        self.throttle1.setF2(False)
        self.waitMsec(5000)
        self.throttle1.setF4(True)
        self.waitMsec(500)
        self.throttle1.setF4(False)
        self.waitMsec(500)
        Kollib.drive_vehicle(self, self.throttle1, 0.5, False)

        Kollib.delay_stop(self, self.throttle1, SensorsList3[5], 0)#Do ustawienia
        self.throttle1.setF2(True)
        self.waitMsec(500)
        self.throttle1.setF2(False)
        self.waitMsec(5000)
        self.throttle1.setF4(True)
        self.waitMsec(500)
        self.throttle1.setF4(False)
        self.waitMsec(500)
        Kollib.drive_vehicle(self, self.throttle1, 0.5, False)
        self.waitMsec(2000)
        PRZEJAZD_STOP.setState(2)



        Kollib.delay_stop(self, self.throttle1, SensorsList3[3], 0)#Do ustawienia
        PRZEJAZD_STOP.setState(4)
        self.waitMsec(200)
        self.throttle1.setF2(True)
        self.waitMsec(500)
        self.throttle1.setF2(False)
        self.waitMsec(5000)
        self.throttle1.setF4(True)
        self.waitMsec(500)
        self.throttle1.setF4(False)
        self.waitMsec(500)
        Kollib.drive_vehicle(self, self.throttle1, 0.5, False)
        self.waitMsec(100)


        Kollib.delay_stop(self, self.throttle1, SensorsList3[2], 4000)
        self.throttle1.setF2(True)
        self.waitMsec(500)
        self.throttle1.setF2(False)
        self.waitMsec(5000)
        return 1



Lok3().start()

