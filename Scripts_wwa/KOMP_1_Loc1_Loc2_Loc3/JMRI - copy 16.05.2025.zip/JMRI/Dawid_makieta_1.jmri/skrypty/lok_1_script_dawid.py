import jarray
import jmri
import sys, os

# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py
sys.path.append(os.path.join(sys.path[0])) #szuka biblioteczki w tym samym folderze w ktorym jest uruchamiany skrypt
import Kollib #Biblioteka autorskich funkcji

#Sekwencyjne przypisywanie adresów sensorą - trasa tramwaj
FirstSensorAdress = 0
NumberOfSensors = 7
SensorsList1 = []
for i in range(FirstSensorAdress, FirstSensorAdress + NumberOfSensors):
    SensorsList1.append(sensors.getSensor("LS"+str(i+1)))
print("Sensor List 1:", SensorsList1)



'''
Jeśli czujniki nie są ułożone w sekwencji, możesz dodać je jako Sensor1 = sensors.getSensor("LS1") lub
SensorsList.append(sensors.getSensor("LS" + str(1))), jeśli chcesz umieścić je w liście.

Jeśli to możliwe, dopisz taki sam algorytm dla innych elementów.

Jeśli dany sensor nie znajduje sie na liście sensorów w panelu "PanelPro" 
(jego wartość to None), skutkuje to wyłaczeniem watku w którym znajduje sie fukcja
odnoszaca sie do tego czujnika.
'''


class Lok1_Dawid(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.
        print("LOK1 Program tramwaj burza uruchomiony...  Czekam na sensor IS1.. ze skryptu startup..")
        self.waitMsec(3000)
        """Sensor wirtualny uruchamiajacy makiete - czekam na odpowiedz z startup_script.py"""
        self.sensorStart = sensors.getSensor("IS20")
        self.sensorStop = sensors.getSensor("IS21")
        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(10, False) #Tramwaj
        return

    def handle(self):
        # handle() is called repeatedly until it returns false.
        print("LOK1 Dawid Program LOK1_HANDLE uruchomiony")


        def open_door():
            self.waitMsec(100)
            self.throttle1.setF3(False)
            self.waitMsec(100)
            self.waitMsec(5000)
            self.throttle1.setF3(True)
            self.waitMsec(100)
            return

        def driving_loop():
            self.waitMsec(100)
            self.throttle1.setF3(True)


            self.waitSensorActive([self.sensorStart])
            print("w driving loop")

            self.waitSensorActive([SensorsList1[0]])
            Kollib.drive_vehicle(self,self.throttle1,0.4, True)
            self.waitMsec(100)

            Kollib.delay_stop(self,self.throttle1,SensorsList1[1],2000)
            self.waitMsec(100)
            open_door()
            self.waitMsec(4000)
            Kollib.drive_vehicle(self,self.throttle1,0.6, True)
            self.waitMsec(100)

            self.waitSensorActive([SensorsList1[2]])
            self.waitMsec(100)
            self.throttle1.setSpeedSetting(0.8)
            self.waitMsec(100)

            self.waitSensorActive([SensorsList1[4]])
            self.waitMsec(100)
            self.throttle1.setSpeedSetting(0.6)
            self.waitMsec(100)

            Kollib.delay_stop(self, self.throttle1, SensorsList1[6], 500)
            self.waitMsec(100)
            open_door()
            self.waitMsec(4000)
            Kollib.drive_vehicle(self, self.throttle1, 0.8, True)
            self.waitMsec(100)



            return

        def koniec():

            while self.sensorStart == INACTIVE :
                print ("Zatrzymany program")
                self.sensorStop.setState(ACTIVE)
                self.waitMsec(100)
                self.waitSensorActive([self.sensorStart])
                self.waitMsec(100)
                self.sensorStop.setState(ACTIVE)


        driving_loop()
        self.waitMsec(100)
        koniec()
        self.waitMsec(100)
        return 1

Lok1_Dawid().start()

