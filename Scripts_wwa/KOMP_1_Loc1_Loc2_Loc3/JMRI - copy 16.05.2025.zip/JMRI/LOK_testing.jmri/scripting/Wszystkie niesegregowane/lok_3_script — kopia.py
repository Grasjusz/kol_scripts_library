import jarray
import jmri
import sys 
import os

# -*- coding: utf-8 -*-

# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py (ustawiony glowny katalog skryptow)
sys.path.append(os.path.join(sys.path[0])) #szuka biblioteczki w tym samym folderze w ktorym jest uruchamiany skrypt
import Kollib #Biblioteka autorskich funkcji

# Definiowanie poszczególnych elementów ścieżki do pliku - w celu dostosowania pod wlasne potrzeby
user_folder = "C:\\Users\\LOK_1"
jmri_folder = "JMRI"
file_name_LOK_3 = "lok_3_end_day_initial_position_kopia.py"  # nazwa pliku do otwarcia

# Tworzenie pełnej ścieżki za pomocą os.path.join
file_path_LOK_3_emergency = os.path.join(user_folder, jmri_folder, "LOK_testing.jmri", "scripting", file_name_LOK_3)

# Sensory wisla
LS33 = sensors.getSensor("LS33") #Czujnik 0 Lista 1 
LS34 = sensors.getSensor("LS34") #Czujnik 1 Lista 1
LS35 = sensors.getSensor("LS35") #Czujnik 2 Lista 1
LS36 = sensors.getSensor("LS36") #Czujnik 3 Lista 1
LS37 = sensors.getSensor("LS37") #Czujnik 4 Lista 1
LS38 = sensors.getSensor("LS38") #Czujnik 5 Lista 1
LS39 = sensors.getSensor("LS39") #Czujnik 6 Lista 1
LS40 = sensors.getSensor("LS40") #Czujnik 7 Lista 1
LS41 = sensors.getSensor("LS41") #Czujnik 8 Lista 1
LS42 = sensors.getSensor("LS42") #Czujnik 9 Lista 1
LS43 = sensors.getSensor("LS43") #Czujnik 10 Lista 1


#Czy modul zwrotnic dziala i nie resetuje sie? - wylaczamy sprawdzanie zwrotnic DO PRZEROBIENIA DO PRZEROBIENIA JAK W LOK2
"""FirstTurnoutAdress = 104
NumberOfTurnouts = 2
TurnoutsList_BCD = []
for i in range(FirstTurnoutAdress, FirstTurnoutAdress + NumberOfTurnouts):
    TurnoutsList_BCD.append(turnouts.getTurnout("LT"+str(i)))"""
#print("Turnout List 1:", TurnoutsList_BCD)


class Lok3(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.

        # Sensor sprzezony z startup_script - uruchamiajacy makiete - pierwsze uruchomienie
        sensor_lok_3 = sensors.getSensor("IS101")
        self.waitSensorActive(sensor_lok_3)
        self.waitMsec(3000)

        # Uruchomienie pociagu na stacje startowe
        exec(open(file_path_LOK_3_emergency).read(), globals())

        print("LOK3 Program tramwaj wisla uruchomiony...  Czekam na sensor IS3.. ze skryptu startup..")
        self.waitMsec(1000)
        
        #Sensor wirtualny sprawdzający stacje poczatkowa
        self.startup_sensor_1 = sensors.getSensor("IS3")  # Pozycja startowa tramwaj wisla
        self.waitSensorActive(self.startup_sensor_1)

        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(11, False) #Tramwaj
        #self.throttle2 = self.getThrottle(11, False) #Tramwaj 2 na wahadlo z 1
        return

    def handle(self):
        # handle() is called repeatedly until it returns false.
        print("LOK3 Program LOK3_HANDLE uruchomiony")

        speed_global = 0.4 # Ustawiamy jedną zmienna główną prędkosc
        
        #Wylaczam sprawdzanie zwrotnic - modul nie dziala DO PRZEROBIENIA JAK W LOK2
        """
        def turnouts_initial_positions():
            #Sprawdz czy zwrotnice sa w odpowiednim polozeniu i ustaw na pozycje startowe
            # 2 dla CLOSED, 4 dla THROW
            
            if TurnoutsList_BCD[0].getKnownState() == 2:
                TurnoutsList_BCD[0].setState(4)
                self.waitMsec(1000)
                print("LOK3 Przestawiam zwrotnice na THROWN:", TurnoutsList_BCD[0], TurnoutsList_BCD[0].getKnownState())

            elif TurnoutsList_BCD[1].getKnownState() == 2:
                TurnoutsList_BCD[1].setState(4)
                self.waitMsec(1000)
                print("LOK3 Przestawiam zwrotnice na THROWN:", TurnoutsList_BCD[1], TurnoutsList_BCD[1].getKnownState())

            else:
                TurnoutsList_BCD[0].setState(4)
                self.waitMsec(1000)
                print("LOK3 Przestawiam zwrotnice na THROWN:", TurnoutsList_BCD[0], TurnoutsList_BCD[0].getKnownState())
                TurnoutsList_BCD[1].setState(4)
                self.waitMsec(1000)
                print("LOK3 Przestawiam zwrotnice na THROWN:", TurnoutsList_BCD[1], TurnoutsList_BCD[1].getKnownState())
            return 0
        """

        while True:
            def check_stop():
                """Sensor wirtualny zatrzymujacy lub uruchamiajacy z powrotem makiete"""
                self.startup_sensor_1 = sensors.getSensor("IS3")  # Pozycja startowa tramwaj wisla
                suspend = self.waitSensorActive(self.startup_sensor_1)

                if suspend == ACTIVE:
                    pass
                elif suspend != ACTIVE:
                    print("LOK3 Pociagi zatrzymane LOK_3_wisla")
                    Kollib.drive_vehicle(self, self.throttle1, 0, True)
                    print("LOK3 Pauza wlaczona..")
                return

            """Jedzie do przodu - wozek napedowy z przodu"""
            def forward_train():

                # Sensor 0 wylaczony - mozna wykorzystac kiedy bedzie wlasciwy tramwaj
                """
                self.waitSensorActive(LS33)
                #print("Czujnik zajety: ", LS34)
                self.waitMsec(100)
                """
                #print("STATE: ", LS33.state)
                print("LOK3 TRASA DO LOTNISKA")
                self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(500)
                if LS34.state == ACTIVE:
                    #print("STATE1: ", LS34.state)
                    #print("Czujnik zajety: ", LS34)
                    self.waitMsec(100)
                    print("LOK3 Start ze stacji 1 - LOK3 TRASA DO LOTNISKA")
                    self.throttle1.setF1(True) # wlacz dzwiek silnika
                    self.waitMsec(8000)
                    self.throttle1.setF0(True)# Zapal światła
                    self.waitMsec(100)
                    self.throttle1.setF4(True) # Wlacz dzwonek przed ruszeniem
                    self.waitMsec(100)
                    self.throttle1.setF4(False) # Wylacz dzwonek przed ruszeniem
                    self.waitMsec(4000)
                    self.throttle1.setF2(True) # Wlacz trabnij przed ruszeniem
                    self.waitMsec(1000)
                    self.throttle1.setF2(False) # Wylacz trabnij przed ruszeniem
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle1, speed_global, True)
                    self.waitMsec(100)

                    self.waitSensorActive(LS35)
                    #print("Czujnik zajety: ", LS35)
                    self.waitMsec(100)
                    print("LOK3 Zatrzymanie na stacji 2 - LOK3 TRASA DO LOTNISKA")
                    Kollib.delay_stop(self, self.throttle1, LS35, 3000)
                    Kollib.stop_at_station(self, self.throttle1, LS35, 6000)
                    print("LOK3 Start ze stacji 2 - LOK3 TRASA DO LOTNISKA")
                    self.throttle1.setF4(True) # Wlacz dzwonek przed ruszeniem
                    self.waitMsec(100)
                    self.throttle1.setF4(False) # Wylacz dzwonek przed ruszeniem
                    self.waitMsec(4000)
                    self.throttle1.setF2(True) # Wlacz trabnij przed ruszeniem
                    self.waitMsec(1000)
                    self.throttle1.setF2(False) # Wylacz trabnij przed ruszeniem
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle1, speed_global, True)
                    self.waitMsec(500)

                    self.waitSensorActive(LS37)
                    #print("Czujnik zajety: ", LS37)
                    self.waitMsec(100)
                    print("LOK3 Zatrzymanie na stacji 3 - LOK3 TRASA DO LOTNISKA")
                    Kollib.delay_stop(self, self.throttle1, LS37, 1000)
                    Kollib.stop_at_station(self, self.throttle1, LS37, 6000)
                    print("LOK3 Start ze stacji 3 - LOK3 TRASA DO LOTNISKA")
                    self.throttle1.setF4(True) # Wlacz dzwonek przed ruszeniem
                    self.waitMsec(100)
                    self.throttle1.setF4(False) # Wylacz dzwonek przed ruszeniem
                    self.waitMsec(4000)
                    self.throttle1.setF2(True) # Wlacz trabnij przed ruszeniem
                    self.waitMsec(1000)
                    self.throttle1.setF2(False) # Wylacz trabnij przed ruszeniem
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle1, speed_global, True)
                    self.waitMsec(100)

                    self.waitSensorActive(LS40)
                    #print("Czujnik zajety: ", LS40)
                    print("LOK3 Zatrzymanie na stacji 4 - LOK3 TRASA DO LOTNISKA")
                    Kollib.delay_stop(self, self.throttle1, LS40, 2500)
                    Kollib.stop_at_station(self, self.throttle1, LS40, 6000)
                    print("LOK3 Start ze stacji 4 - LOK3 TRASA DO LOTNISKA")
                    self.throttle1.setF4(True) # Wlacz dzwonek przed ruszeniem
                    self.waitMsec(100)
                    self.throttle1.setF4(False) # Wylacz dzwonek przed ruszeniem
                    self.waitMsec(4000)
                    self.throttle1.setF2(True) # Wlacz trabnij przed ruszeniem
                    self.waitMsec(1000)
                    self.throttle1.setF2(False) # Wylacz trabnij przed ruszeniem
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle1, speed_global, True)
                    Kollib.speed_change(self, self.throttle1, 0.5) #zmiana predkosci
                    self.waitMsec(100)

                    self.waitSensorActive(LS41)
                    #print("Czujnik zajety: ", LS41)
                    self.waitMsec(100)

                    self.waitSensorActive(LS43)
                    #print("Czujnik zajety: ", LS43)
                    Kollib.speed_change(self, self.throttle1, 0.5) #zmiana predkosci
                    self.waitMsec(100)

                    self.waitSensorActive(LS42)
                    #print("Czujnik zajety: ", LS42)
                    print("LOK3 Zatrzymanie na stacji 5 - LOK3 TRASA DO LOTNISKA")
                    Kollib.delay_stop(self, self.throttle1, LS42, 1500)
                    Kollib.stop_at_station(self, self.throttle1, LS42, 6000)
                    print("LOK3 Stacja KONCOWA - stacja 5 - LOK3 TRASA DO LOTNISKA")
                    self.throttle1.setF0(False) # Zgaś światła
                    self.waitMsec(100)
                    self.throttle1.setF1(False) #wylacz dzwiek silnika
                    self.waitMsec(8000)
                    print("LOK3 KONIEC PETLI DO LOTNISKA, ROZPOCZYNAM NOWA LOK_3")
                    return 0

            """Jedzie do tylu - wozek napedowy z przodu"""
            def backward_train():
                #print("STATE: ", LS33.state)
                #print("Inside handle(backward_train)")
                self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(500)
                if LS42.state == ACTIVE:
                    #print("STATE1: ", LS42.state)
                    #print("Czujnik zajety: ", LS42)
                    self.waitMsec(100)
                    print("LOK3 Start ze stacji 5 - LOK3 TRASA DO POMNIKA")
                    self.throttle1.setF1(True)  # wlacz dzwiek silnika
                    self.waitMsec(8000)
                    self.throttle1.setF0(True)  # Zapal światła
                    self.waitMsec(100)
                    self.throttle1.setF4(True) # Wlacz dzwonek przed ruszeniem
                    self.waitMsec(100)
                    self.throttle1.setF4(False) # Wylacz dzwonek przed ruszeniem
                    self.waitMsec(4000)
                    self.throttle1.setF2(True) # Wlacz trabnij przed ruszeniem
                    self.waitMsec(1000)
                    self.throttle1.setF2(False) # Wylacz trabnij przed ruszeniem
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle1, speed_global, False)
                    self.waitMsec(4000)

                    self.waitSensorActive(LS43)
                    #print("Czujnik zajety: ", LS43)
                    self.waitMsec(100)

                    self.waitSensorActive(LS41)
                    #print("Czujnik zajety: ", LS41)
                    Kollib.speed_change(self, self.throttle1, 0.5) #zmiana predkosci
                    self.waitMsec(100)

                    self.waitSensorActive(LS40)
                    #print("Czujnik zajety: ", LS40)
                    print("LOK3 Zatrzymanie na stacji 4 - LOK3 TRASA DO POMNIKA")
                    Kollib.delay_stop(self, self.throttle1, LS40, 2000)
                    Kollib.stop_at_station(self, self.throttle1, LS40, 6000)
                    print("LOK3 Start ze stacji 4 - LOK3 TRASA DO POMNIKA")
                    self.throttle1.setF4(True)  # Wlacz dzwonek przed ruszeniem
                    self.waitMsec(100)
                    self.throttle1.setF4(False)  # Wylacz dzwonek przed ruszeniem
                    self.waitMsec(4000)
                    self.throttle1.setF2(True)  # Wlacz trabnij przed ruszeniem
                    self.waitMsec(1000)
                    self.throttle1.setF2(False)  # Wylacz trabnij przed ruszeniem
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle1, speed_global, False)


                    # Sensor 37 wylaczony - mozna wykorzystac kiedy bedzie wlasciwy tramwaj
                    """
                    self.waitSensorActive(LS37)
                    #print("Czujnik zajety: ", LS37)
                    self.waitMsec(100)
                    Kollib.speed_change(self, self.throttle1, 0.5) #zmiana predkosci
                    self.waitMsec(100)
                    """

                    self.waitSensorActive(LS37)
                    #print("Czujnik zajety: ", LS37)
                    self.waitMsec(100)
                    print("LOK3 Zatrzymanie na stacji 3 - LOK3 TRASA DO POMNIKA")
                    Kollib.delay_stop(self, self.throttle1, LS37, 1500)
                    Kollib.stop_at_station(self, self.throttle1, LS37, 6000)
                    print("LOK3 Start ze stacji 3 - LOK3 TRASA DO POMNIKA")
                    self.throttle1.setF4(True)  # Wlacz dzwonek przed ruszeniem
                    self.waitMsec(100)
                    self.throttle1.setF4(False)  # Wylacz dzwonek przed ruszeniem
                    self.waitMsec(4000)
                    self.throttle1.setF2(True)  # Wlacz trabnij przed ruszeniem
                    self.waitMsec(1000)
                    self.throttle1.setF2(False)  # Wylacz trabnij przed ruszeniem
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle1, speed_global, False)
                    self.waitMsec(100)

                    self.waitSensorActive(LS35)
                    #print("Czujnik zajety: ", LS35)
                    Kollib.speed_change(self, self.throttle1, 0.5) #zmiana predosci
                    print("LOK3 Zatrzymanie na stacji 2 - LOK3 TRASA DO POMNIKA")
                    Kollib.delay_stop(self, self.throttle1, LS35, 1000)
                    Kollib.stop_at_station(self, self.throttle1, LS35, 6000)
                    self.waitMsec(100)
                    self.throttle1.setF4(True)  # Wlacz dzwonek przed ruszeniem
                    self.waitMsec(100)
                    self.throttle1.setF4(False)  # Wylacz dzwonek przed ruszeniem
                    self.waitMsec(4000)
                    self.throttle1.setF2(True)  # Wlacz trabnij przed ruszeniem
                    self.waitMsec(1000)
                    self.throttle1.setF2(False)  # Wylacz trabnij przed ruszeniem
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle1, speed_global, False)
                    self.waitMsec(6000)
                    Kollib.speed_change(self, self.throttle1, 0.6) #zmiana predkosci

                    # Sensor 33 wylaczony - mozna wykorzystac kiedy bedzie wlasciwy tramwaj
                    """
                    self.waitSensorActive(LS33)
                    #print("Czujnik zajety: ", LS33)
                    Kollib.speed_change(self, self.throttle1, 0.5)
                    self.waitMsec(100)
                    """

                    self.waitSensorActive(LS34)
                    print("LOK3 Czujnik zajety: ", LS34)
                    print("LOK3 Zatrzymanie na stacji 1 - LOK3 TRASA DO POMNIKA")
                    Kollib.delay_stop(self, self.throttle1, LS34, 6500)
                    Kollib.stop_at_station(self, self.throttle1, LS34, 4000)
                    print("LOK3 Stacja KONCOWA - stacja 1 - LOK3 TRASA DO POMNIKA")
                    self.throttle1.setF0(False)  # Zgaś światła
                    self.waitMsec(100)
                    self.throttle1.setF1(False)  # wylacz dzwiek silnika
                    self.waitMsec(10000)
                    print("LOK3 KONIEC PETLI DO POMNIKA, ROZPOCZYNAM NOWA LOK_3")
                    return 0

            """Uruchom odpowiednia funkcje zalezna od tego na ktorym torze krancowym sie znajduje"""
            if LS34.state == ACTIVE:
                print("LOK3 Sprawdzam czy pauza..")
                check_stop()
                print("LOK3 Uruchamiam funkcje TRAM WISLA DO LOTNISKA")
                # turnouts_initial_positions() - wylaczamy tymaczsowe sprawdzanie zwrotnic
                forward_train()
            elif LS42.state == ACTIVE:
                print("LOK3 Uruchamiam funkcje TRAM WISLA DO POMNIKA")
                # turnouts_initial_positions() - wylaczamy tymaczsowe sprawdzanie zwrotnic
                backward_train()
            else:
                self.waitMsec(5000)


Lok3().start()

