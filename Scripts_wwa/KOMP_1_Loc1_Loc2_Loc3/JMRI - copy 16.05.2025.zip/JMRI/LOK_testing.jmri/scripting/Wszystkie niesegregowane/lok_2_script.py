import jarray
import jmri
import sys 
import os

# -*- coding: utf-8 -*-

# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py (ustawiony glowny katalog skryptow)
sys.path.append(os.path.join(sys.path[0])) #szuka biblioteczki w tym samym folderze w ktorym jest uruchamiany skrypt
import Kollib #Biblioteka autorskich funkcji

# Definiowanie poszczególnych elementów ścieżki do pliku - w celu dostosowania pod wlasne potrzeby
user_folder = "C:\\Users\\LOK_1"
jmri_folder = "JMRI"
file_name_LOK_2 = "lok_2_end_day_initial_position_kopia.py"  # nazwa pliku do otwarcia

# Tworzenie pełnej ścieżki za pomocą os.path.join
file_path_LOK_2_emergency = os.path.join(user_folder, jmri_folder, "LOK_testing.jmri", "scripting", file_name_LOK_2)

#Sensory osobowe
LS17 = sensors.getSensor("LS17") #Czujnik 0 Lista 1 
LS18 = sensors.getSensor("LS18") #Czujnik 1 Lista 1 
LS19 = sensors.getSensor("LS19") #Czujnik 2 Lista 1 
LS20 = sensors.getSensor("LS20") #Czujnik 3 Lista 1 
LS21 = sensors.getSensor("LS21") #Czujnik 4 Lista 1 
LS22 = sensors.getSensor("LS22") #Czujnik 5 Lista 1 
#print("LOK2 Sensor osobowy: ", LS17, LS18, LS19, LS20, LS21, LS22)

#Sensory towarowe
LS23 = sensors.getSensor("LS23") #Czujnik 0 Lista 2
LS24 = sensors.getSensor("LS24") #Czujnik 1 Lista 2
LS25 = sensors.getSensor("LS25") #Czujnik 2 Lista 2
LS26 = sensors.getSensor("LS26") #Czujnik 3 Lista 2
LS27 = sensors.getSensor("LS27") #Czujnik 4 Lista 2
LS28 = sensors.getSensor("LS28") #Czujnik 5 Lista 2
LS29 = sensors.getSensor("LS29") #Czujnik 6 Lista 2
LS30 = sensors.getSensor("LS30") #Czujnik 7 Lista 2
LS31 = sensors.getSensor("LS31") #Czujnik 8 Lista 2
LS32 = sensors.getSensor("LS32") #mijanka/wahadlo 
#print("LOK2 Sensor towarowy: ", LS23, LS24, LS25, LS26, LS27, LS28, LS29, LS30, LS31, LS32)

#Zwrotnice
LT100 = turnouts.getTurnout("LT100") #Zwrotnica 1
LT101 = turnouts.getTurnout("LT101") #Zwrotnica 2
LT102 = turnouts.getTurnout("LT102") #Zwrotnica 3
LT103 = turnouts.getTurnout("LT103") #Zwrotnica 4
#print("LOK2 Zwrotnice: ", LT100, LT101, LT102, LT103)

class Lok2(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.

        # Sensor sprzezony z startup_script - uruchamiajacy makiete - pierwsze uruchomienie
        sensor_lok_2 = sensors.getSensor("IS100")
        self.waitSensorActive(sensor_lok_2)

        print("LOK2 Program wawa wilenska uruchomiony...  Czekam na sensor IS5 i IS6..")

        # Uruchomienie pliku na stacje startowe
        exec(open(file_path_LOK_2_emergency).read(), globals())

        #Sensor wirtualny sprawdzający stacje poczatkowa
        self.startup_sensor_1 = sensors.getSensor("IS5")  # Pozycja startowa pociag pasazerski
        self.startup_sensor_2 = sensors.getSensor("IS6")  # Pozycja startowa pociag towarowy
        self.waitSensorActive(self.startup_sensor_1)
        self.waitSensorActive(self.startup_sensor_2)


        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(3, False) #Pociag osobowy
        self.throttle2 = self.getThrottle(6, False) #V20, towarowy

    def handle(self):
        # handle() is called repeatedly until it returns false.
        print("LOK2 Program LOK2_HANDLE uruchomiony")

        while True:

            def check_stop():
                """Sensor wirtualny zatrzymujacy lub uruchamiajacy z powrotem makiete"""
                self.startup_sensor_1 = sensors.getSensor("IS5")  # Pozycja startowa pociag osobowy
                self.startup_sensor_2 = sensors.getSensor("IS6")  # Pozycja startowa pociag towarowy

                suspend_1 = self.waitSensorActive(self.startup_sensor_1)
                suspend_2 = self.waitSensorActive(self.startup_sensor_2)

                if suspend_1 == ACTIVE and suspend_2 == ACTIVE:
                    pass #kontynuuj program
                elif suspend_1 != ACTIVE and suspend_2 != ACTIVE:
                    print("LOK2 Pociagi zatrzymane LOK_2_wilenska")
                    Kollib.drive_vehicle(self, self.throttle1, 0, True) #zatrzymaj pociag osobowy i czekaj na zmiane sygnalu
                    Kollib.drive_vehicle(self, self.throttle2, 0, True) #zatrzymaj pociag towarowy i czekaj na zmiane sygnalu
                    print("LOK2 Pauza wlaczona..")
                return

            def turnouts_initial_positions():
                """Sprawdz czy zwrotnice sa w odpowiednim polozeniu i ustaw na pozycje startowe"""
                """#2 dla CLOSED, #4 dla THROW"""
                if LT100.getKnownState() == 2:
                    LT100.setState(4)
                    self.waitMsec(1000)
                    #("LOK2 Przestawiam zwrotnice na THROWN:", LT100, LT100.getKnownState())

                elif LT101.getKnownState() == 2:
                    LT101.setState(4)
                    self.waitMsec(1000)
                    #print("LOK2 Przestawiam zwrotnice na THROWN:", LT101, LT101.getKnownState())

                elif LT102.getKnownState() == 2:
                    LT102.setState(4)
                    self.waitMsec(1000)
                    #print("LOK2 Przestawiam zwrotnice na THROWN:", LT102, LT102.getKnownState())

                elif LT103.getKnownState() == 2:
                    LT103.setState(4)
                    self.waitMsec(1000)
                    #print("LOK2 Przestawiam zwrotnice na THROWN:", LT103, LT103.getKnownState())
                return 0

            """Funkcje dekoracyjne uruchamiajace pociag osobowy"""
            def startup_tram():
                self.throttle1.setF3(True)#Unieś pantografy
                self.waitMsec(1000)
                self.throttle1.setF6(True) # wlacz dzwiek silnika
                self.waitMsec(3000)
                self.throttle1.setF17(True)# Oświetlenie stacji docelowej pociagu
                self.waitMsec(100)
                self.throttle1.setF0(True)# Wlaczenie swiatel pociagu
                self.waitMsec(100)
                self.throttle1.setF18(True)# Zamykanie drzwi
                self.waitMsec(4000)
                self.throttle1.setF18(False)# Zamykanie drzwi
                self.waitMsec(2000)
                return
            
            """Funkcje dekoracyjne wylaczajaca pociag osobowy"""
            def shutdown_tram():
                self.throttle1.setF0(False)# Wylaczenie swiatel pociagu
                self.waitMsec(100)
                self.throttle1.setF3(False)# Opuść pantografy
                self.waitMsec(1000)
                self.throttle1.setF6(False) # wylacz dzwiek silnika
                self.waitMsec(3000)
            
            """Funkcje dekoracyjne zamykajace drzwi pociag osobowy"""
            def doors_tram():
                self.throttle1.setF18(True)# Zamykanie drzwi
                self.waitMsec(4000)
                self.throttle1.setF18(False)# Zamykanie drzwi
                self.waitMsec(2000)
                return
            """Funkcje dekoracyjne uruchamiajace pociag towarowy"""
            def startup_train():
                self.throttle2.setF0(True)# Zapal światła
                self.throttle2.setF1(True) # wlacz dzwiek silnika
                self.waitMsec(10000)
                return
            
            """Funkcje dekoracyjne wylaczajaca pociag towarowy"""
            def shutdown_train():
                self.throttle2.setF0(False)# Zgaś światła
                self.waitMsec(100)
                self.throttle2.setF1(False)# wylacz dzwiek silnika
                self.waitMsec(3000)
                return


            """Jedzie do tylu - wozek napedowy z przodu"""
            def backward_tram():
                #print("STATE: ", LS17.state)
                print("LOK2 POCIAG OSOBOWY TRASA DO BUNKROW)")
                self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(500)
                if LS17.state == ACTIVE:
                    #print("Czujnik zajety: ", LS17)
                    startup_tram() # funkcje dekoracyjne, uruchamianie pociagu osobowego
                    Kollib.drive_vehicle(self, self.throttle1, 0.4, False)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS18)
                    #print("Czujnik zajety: ", LS18)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS19)
                    #print("Czujnik zajety: ", LS19)
                    print("LOK2 Zatrzymanie na stacji 2 - BUNKRY TRASA DO BUNKROW")
                    Kollib.delay_stop(self, self.throttle1, LS19, 1)#stop gora stacja
                    self.waitMsec(100)
                    print("LOK2 Pociag towarowy powraca - warszawa wilenska")
                    backward_train()  # uruchom pociag towarowy do powrotu
                    print("LOK2 Pociag towarowy powrocil - warszawa wilenska")
                    doors_tram()  # funkcja dekoracyjna zamykajaca drzwi
                    print("LOK2 Start na stacji 2 - TRASA DO BUNKROW")
                    Kollib.drive_vehicle(self, self.throttle1, 0.4, False)
                    
                    #ustawienie predkosci i czasu bo brakuje czujnikow ktore pozwola plynnie zarzadzac dojechaniem do stacji
                    self.waitSensorActive(LS20)
                    #print("Czujnik zajety: ", LS20)
                    self.waitMsec(100)
                    Kollib.speed_change(self, self.throttle1, 0.4) # zwolnienie przed czujnikiem
                    self.waitMsec(20000)
                    Kollib.speed_change(self, self.throttle1, 0.1) # Maksymalne zwolnienie tuz przed czujnikiem koncowym
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS21)
                    #print("Czujnik zajety: ", LS21)
                    print("LOK2 Zatrzymanie na stacji 3 - TRASA DO BUNKROW")
                    self.waitMsec(100)
                    Kollib.delay_stop(self, self.throttle1, LS21, 100)
                    shutdown_tram() # funkcja dekoracyjna zamykajaca wylaczaja silnik i pantografy
                    print("LOK2 KONIEC PETLI, ROZPOCZYNAM NOWA LOK_2_WAWA_WILENSKA")
                    return

            """Jedzie do przodu - wozek napedowy z przodu"""
            def forward_tram():
                #print("STATE: ", LS17.state)
                print("LOK2 POCIAG OSOBOWY TRASA DO WAWA WILENSKA")
                self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(500)
                if LS21.state == ACTIVE:
                    #print("STATE1: ", LS21.state)
                    #print("Czujnik zajety: ", LS21)
                    startup_tram() # funkcje dekoracyjne, uruchamianie pociagu osobowego
                    print("LOK2 Start na stacji 3 - TRASA WAWA WILENSKA")
                    Kollib.drive_vehicle(self, self.throttle1, 0.4, True)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS20)
                    #print("Czujnik zajety: ", LS20)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS19)
                    #print("Czujnik zajety: ", LS19)
                    print("LOK2 Zatrzymanie na stacji 2 - TRASA WAWA WILENSKA")
                    Kollib.delay_stop(self, self.throttle1, LS19, 1000)#stop gora stacja
                    self.waitMsec(2000)
                    print("LOK2 Pociag towarowy wyrusza - trasa do warszawa bunkry")
                    forward_train()#uruchom pociag towarowy do powrotu
                    print("LOK2 Pociag towarowy dojechal - trasa do warszawa bunkry")
                    doors_tram()  # funkcja dekoracyjna zamykajaca drzwi
                    print("LOK2 Start na stacji 2 - TRASA WAWA WILENSKA")
                    Kollib.drive_vehicle(self, self.throttle1, 0.4, True)
                    
                    self.waitSensorActive(LS18)
                    #print("Czujnik zajety: ", LS18)
                    Kollib.speed_change(self, self.throttle1, 0.3)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS17)
                    #print("Czujnik zajety: ", LS17)
                    print("LOK2 Zatrzymanie na stacji 1 - TRASA WAWA WILENSKA")
                    self.waitMsec(100)
                    Kollib.delay_stop(self, self.throttle1, LS17, 2000)
                    self.waitMsec(10000)
                    Kollib.drive_vehicle(self, self.throttle1, 0.1, True) #rusz do przodu aby wzbudzic czujnik
                    self.waitMsec(1500)
                    Kollib.delay_stop(self, self.throttle1, LS17, 100)
                    shutdown_tram() # funkcja dekoracyjna zamykajaca wylaczaja silnik i pantografy
                    print("LOK2 KONIEC PETLI, ROZPOCZYNAM NOWA LOK_2_WAWA_WILENSKA")
                    return

            """Jedzie do przodu - wozek napedowy z przodu"""
            def forward_train():
                #print("STATE: ", LS27.state)
                print("LOK2 POCIAG TOWAROWY - TRASA DO BUNKRY")
                self.throttle2.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(500)
                if LS27.state == ACTIVE:
                    #print("STATE1: ", LS27.state)
                    #print("Czujnik zajety: ", LS27)
                    self.waitMsec(100)
                    print("LOK2 Start na stacji 1 - TRASA DO BUNKRY")
                    startup_train() # funkcje dekoracyjne, uruchamianie pociagu towarowego
                    Kollib.drive_vehicle(self, self.throttle2, 0.5, True) #ustawienie predkosci
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS28)
                    #print("Czujnik zajety: ", LS28)
                    self.waitMsec(100)
                    self.throttle2.setF2(True)# wlacz klakson w tunelu
                    self.waitMsec(4500)
                    self.throttle2.setF2(False)# wylacz klakson w tunelu
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS29)
                    #print("Czujnik zajety: ", LS29)
                    self.waitMsec(100)
                    Kollib.speed_change(self, self.throttle2, 0.8) # zmiana iloczynu predkosci
                    self.waitMsec(2000)
                    Kollib.speed_change(self, self.throttle2, 0.7) # zmiana iloczynu predkosci
                    self.waitMsec(1500)
                    
                    self.waitSensorActive(LS30)
                    #print("Czujnik zajety: ", LS30)
                    Kollib.speed_change(self, self.throttle2, 0.5)# zmiana iloczynu predkosci
                    self.waitMsec(3000)
                    Kollib.speed_change(self, self.throttle2, 0.3)# zmiana iloczynu predkosci
                    self.waitMsec(1500)
                    Kollib.speed_change(self, self.throttle2, 0.1)# zmiana iloczynu predkosci
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS31)
                    #print("Czujnik zajety: ", LS31)
                    print("LOK2 Zatrzymanie na stacji 3 - TRASA DO BUNKRY")
                    self.waitMsec(100)
                    Kollib.delay_stop(self, self.throttle2, LS31, 500)
                    shutdown_train() # funkcja dekoracyjna zamykajaca wylaczaja silnik
                    return

            def backward_train():
                #print("STATE: ", LS31.state)
                print("LOK2 POCIAG TOWAROWY - TRASA DO WAWA WILENSKA")
                self.throttle2.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(500)
                if LS31.state == ACTIVE:
                    #print("STATE1: ", LS31.state)
                    #print("Czujnik zajety: ", LS27)
                    self.waitMsec(100)
                    self.throttle2.setF3(True)# wlacz stukanie narzedzi
                    self.waitMsec(5000)
                    self.throttle2.setF3(False)# wylacz stukanie narzedzi
                    self.waitMsec(100)
                    print("LOK2 Start na stacji 3 - TRASA WAWA WILENSKA")
                    startup_train() # funkcje dekoracyjne, uruchamianie pociagu towarowego
                    Kollib.drive_vehicle(self, self.throttle2, 0.5, False)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS30)
                    #print("Czujnik zajety: ", LS30)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS29)
                    #print("Czujnik zajety: ", LS29)
                    self.waitMsec(4000)
                    self.throttle2.setF2(True)# wlacz klakson w tunelu
                    self.waitMsec(6000)
                    self.throttle2.setF2(False)# wylacz klakson w tunelu
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS28)
                    #print("Czujnik zajety:", LS28)
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle2, 0.4, False)
                    self.waitMsec(2000)
                    Kollib.drive_vehicle(self, self.throttle2, 0.3, False)
                    self.waitMsec(100)
                    
                    self.waitSensorActive(LS27)
                    #print("Czujnik zajety:", LS27)
                    print("LOK2 Zatrzymanie na stacji 1 - TRASA WAWA WILENSKA")
                    self.waitMsec(100)
                    Kollib.drive_vehicle(self, self.throttle2, 0.1, False)
                    self.waitMsec(3000)
                    Kollib.delay_stop(self, self.throttle2, LS27, 500)
                    shutdown_train() # funkcja dekoracyjna wylaczaja silnik
                    return

            """Uruchom odpowiednia funkcje zalezna od tego na ktorym torze krancowym sie znajduje"""
            if LS17.state == ACTIVE and LS31.state == ACTIVE:
                print("LOK2 Sprawdz czy pauza..")
                check_stop() #sprawdz czy pauza
                print("LOK2 Uruchamiam funkcje resetujaca zwrotnice")
                turnouts_initial_positions() # reset zwrotnic
                print("LOK2 Uruchamiam funkcje backward_tram")
                backward_tram()
            elif LS21.state == ACTIVE and LS27.state == ACTIVE:
                print("LOK2 Uruchamiam funkcje resetująca zwrotnice")
                turnouts_initial_positions() #reset zwrotnic
                print("LOK2 Uruchamiam funkcje forward_tram")
                forward_tram()


Lok2().start()

