import jarray
import jmri
import sys 
import os

# -*- coding: utf-8 -*-

# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py (ustawiony glowny katalog skryptow)
sys.path.append(os.path.join(sys.path[0])) #szuka biblioteczki w tym samym folderze w ktorym jest uruchamiany skrypt
import Kollib  # Biblioteka autorskich funkcji

# Pobierz sensory startowe
startup_sensor_1 = sensors.getSensor("IS5")  # Pozycja startowa pociag pasazerski
startup_sensor_2 = sensors.getSensor("IS6")  # Pozycja startowa pociag towarowy

#Sensory osobowe
LS17 = sensors.getSensor("LS17") #Czujnik 0 Lista 1 
LS18 = sensors.getSensor("LS18") #Czujnik 1 Lista 1 
LS19 = sensors.getSensor("LS19") #Czujnik 2 Lista 1 
LS20 = sensors.getSensor("LS20") #Czujnik 3 Lista 1 
LS21 = sensors.getSensor("LS21") #Czujnik 4 Lista 1 
LS22 = sensors.getSensor("LS22") #Czujnik 5 Lista 1 
#print("LOK2 Sensor osobowy: ", LS17, LS18, LS19, LS20, LS21, LS22)

#Sensory towarowe
LS23 = sensors.getSensor("LS23") #Czujnik 0 Lista 2
LS24 = sensors.getSensor("LS24") #Czujnik 1 Lista 2
LS25 = sensors.getSensor("LS25") #Czujnik 2 Lista 2
LS26 = sensors.getSensor("LS26") #Czujnik 3 Lista 2
LS27 = sensors.getSensor("LS27") #Czujnik 4 Lista 2
LS28 = sensors.getSensor("LS28") #Czujnik 5 Lista 2
LS29 = sensors.getSensor("LS29") #Czujnik 6 Lista 2
LS30 = sensors.getSensor("LS30") #Czujnik 7 Lista 2
LS31 = sensors.getSensor("LS31") #Czujnik 8 Lista 2
LS32 = sensors.getSensor("LS32") #mijanka/wahadlo 
#print("LOK2 Sensor towarowy: ", LS23, LS24, LS25, LS26, LS27, LS28, LS29, LS30, LS31, LS32)

#Zwrotnice
LT100 = turnouts.getTurnout("LT100") #Zwrotnica 1
LT101 = turnouts.getTurnout("LT101") #Zwrotnica 2
LT102 = turnouts.getTurnout("LT102") #Zwrotnica 3
LT103 = turnouts.getTurnout("LT103") #Zwrotnica 4
#print("LOK2 Zwrotnice: ", LT100, LT101, LT102, LT103)

class Lok2EndDay(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.
        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(3, False)  # Tramwaj
        self.throttle2 = self.getThrottle(6, False)  # BR80, towarowy

    def handle(self):
        # handle() is called repeatedly until it returns false.
        print("LOK2 funkcja awaryjna, ustawiam pociagi na pozycje startowe")
        self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
        self.throttle2.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana

        speed_global = 0.2 # Ustawiamy jedną zmienna główną prędkosc

        def turnouts_initial_positions():
            """Sprawdz czy zwrotnice sa w odpowiednim polozeniu i ustaw na pozycje startowe"""
            """#2 dla CLOSED, #4 dla THROW"""
            if LT100.getKnownState() == 2:
                LT100.setState(4)
                self.waitMsec(1000)
                #print("LOK2 Przestawiam zwrotnice na THROWN:", LT100, LT100.getKnownState())

            elif LT101.getKnownState() == 2:
                LT101.setState(4)
                self.waitMsec(1000)
                #print("LOK2 Przestawiam zwrotnice na THROWN:", LT101, LT101.getKnownState())

            elif LT102.getKnownState() == 2:
                LT102.setState(4)
                self.waitMsec(1000)
                #print("LOK2 Przestawiam zwrotnice na THROWN:", LT102, LT102.getKnownState())

            elif LT103.getKnownState() == 2:
                LT103.setState(4)
                self.waitMsec(1000)
                #print("LOK2 Przestawiam zwrotnice na THROWN:", LT103, LT103.getKnownState())
            return
        
        """Mruganie swiatalami podczas dojazdu do stacji startowej"""
        def blinking_lights():
            """Funkcja mrugania swiatlami"""
            self.waitMsec(100)
            self.throttle1.setF0(True)  # wlacz mruganie swiatlami
            self.waitMsec(1000)
            self.throttle1.setF0(False)  # skoncz mruganie swiatlami
            self.waitMsec(100)
            return

        """Dzwiek sygnalizujacy dojazd na stacje startowa - tylko pociag osobowy"""
        def make_noise_tram():
            """Funkcja sygnalizowania dojazdu na stacje startowa"""
            self.throttle1.setF1(False)  # wylacz dzwiek silnika
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(100)
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(100)
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(3000)
            return

        """Dzwiek sygnalizujacy dojazd na stacje startowa - tylko pociag towarowy"""
        def make_noise_train():
            self.throttle1.setF1(False)  # wylacz dzwiek silnika
            self.throttle1.setF0(False)  # zgas światła
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(100)
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(100)
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(3000)
            return

        """Funkcja uruchomieniowa - awaryjny dojazd do stacji startowej jezeli pociag na niej sie nie znajduje
        co okolo sekunde uzywa sygnalu dziekowego - jezeli na niej sie znajduje - trabi 3 razy po 2 sekundy"""
        def drive_to_start_station_tram():
            print("LOK2 POCIAG OSOBOWY Uruchamiam funkcje powrotu na stacje poczatkowe")
            self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
            self.waitMsec(1000)
            if LS17.state != ACTIVE:
                Kollib.drive_vehicle(self, self.throttle1, speed_global, False) # Rusza do tylu szukac czujnika
                self.waitMsec(8000)
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True) # Rusza do przodu by wzbudzic pierwszy czujnik
                Kollib.speed_change(self, self.throttle1, 0.6)
                while LS17.state != ACTIVE:
                    blinking_lights()
                    if LS17.state == ACTIVE:
                        self.waitMsec(1000)
                        if LS18.state != ACTIVE:
                            Kollib.drive_vehicle(self, self.throttle1, 0.0,True)
                            print("LOK2 Pociag dojechal na stacje startowa - koniec petli")
                            return


        """Funkcja wywolujaca funkcje uruchomieniowe dojazdu do stacji startowych"""
        def tram_initial_station_func():

            """Petla odpalajaca powrot do stacji startowej tramwaj"""
            if LS17.state != ACTIVE and LS18.state != ACTIVE:
                print("LOK2 Pociag nie na stacji startowej - uruchamiam funkcje jedz do stacji startowej")
                turnouts_initial_positions()
                drive_to_start_station_tram()
                Kollib.drive_vehicle(self, self.throttle1, 0.0, True)
                print("LOK2 Pociag dojechal na stacji startowej POCIAG OSOBOWY - Koncze skrypt")
                make_noise_tram() # sygnal dzwiekowy wskazujacy dojazd a stacje poczatkowa
                return
            
            elif LS17.state != ACTIVE and LS18.state == ACTIVE:
                print("LOK2 Pociag PRZED stacja startowej - uruchamiam funkcje jedz do stacji startowej")
                turnouts_initial_positions()
                drive_to_start_station_tram()
                Kollib.drive_vehicle(self, self.throttle1, 0.0, True)
                print("LOK2 Pociag dojechal na stacji startowej POCIAG OSOBOWY - Koncze skrypt")
                make_noise_tram() # sygnal dzwiekowy wskazujacy dojazd a stacje poczatkowa
                return

            elif LS17.state == ACTIVE and LS18.state != ACTIVE:
                turnouts_initial_positions()
                Kollib.drive_vehicle(self, self.throttle1, 0.0, True)
                print("LOK2 Pociag stal na stacji startowej POCIAG OSOBOWY - Koncze skrypt")
                return

        """Funkcja uruchomieniowa - awaryjny dojazd do stacji startowej jezeli pociag na niej sie nie znajduje
        to miga swiatlami - jezeli na niej sie znajduje - trabi 3 razy po 2 sekundy"""
        def drive_to_start_station_train():
            print("LOK2 POCIAG TOWAROWY uruchamiam funkcje powrotu na stacje poczatkowe")
            self.throttle2.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
            self.waitMsec(1000)
            if LS31 != ACTIVE:
                Kollib.drive_vehicle(self, self.throttle2, speed_global,True)  # Rusza do przodu by wzbudzic pierwszy czujnik
                Kollib.speed_change(self, self.throttle2, 0.6)
                while LS31.state != ACTIVE:
                    blinking_lights()
                    if LS31.state == ACTIVE:
                        self.waitMsec(1000)
                        if LS30.state != ACTIVE:
                            Kollib.drive_vehicle(self, self.throttle2, 0.0, True)
                            print("LOK2 POCIAG TOWAROWY dojechal na stacje - koniec petli")
                            return


        """Funkcja wywolujaca funkcje uruchomieniowe dojazdu do stacji startowych"""
        def train_initial_station_func():
            """Petla odpalajaca powrot do stacji startowej pociag"""
            if LS31.state != ACTIVE and LS30.state != ACTIVE and LS26 != ACTIVE:
                print("LOK2 POCIAG TOWAROWY nie na stacji startowej - uruchamiam funkcje jedz do stacji startowej")
                turnouts_initial_positions()
                Kollib.drive_vehicle(self, self.throttle2, speed_global, False) # Rusza do tylu szukac czujnika
                self.waitMsec(6000)
                drive_to_start_station_train()
                Kollib.drive_vehicle(self, self.throttle2, 0.0, True)
                print("LOK2 POCIAG TOWAROWY na stacji startowej - Koncze skrypt")
                make_noise_train() # sygnal dzwiekowy wskazujacy dojazd a stacje poczatkowa
                return

            elif LS31.state != ACTIVE and LS30.state == ACTIVE:
                print("LOK2 POCIAG TOWAROWY PRZED stacja startowa - uruchamiam funkcje jedz do stacji startowej")
                turnouts_initial_positions()
                Kollib.drive_vehicle(self, self.throttle2, speed_global, False) # Rusza do tylu szukac czujnika
                self.waitMsec(6000)
                drive_to_start_station_train()
                Kollib.drive_vehicle(self, self.throttle2, 0.0, True)
                print("LOK2 POCIAG TOWAROWY na stacji startowej - Koncze skrypt")
                make_noise_train() # sygnal dzwiekowy wskazujacy dojazd a stacje poczatkowa
                return

            elif LS31.state == ACTIVE and LS30.state != ACTIVE:
                turnouts_initial_positions()
                Kollib.drive_vehicle(self, self.throttle2, 0.0, True)
                print("LOK2 POCIAG TOWAROWY stal na stacji - koniec petli")
                return
            
            elif LS31.state != ACTIVE and LS26.state == ACTIVE:
                turnouts_initial_positions()
                drive_to_start_station_train()
                Kollib.drive_vehicle(self, self.throttle2, 0.0, True)
                print("LOK2 POCIAG TOWAROWY dojechal do stacji - koniec petli")
                make_noise_train() # sygnal dzwiekowy wskazujacy dojazd a stacje poczatkowa
                return

        tram_initial_station_func()
        print("Zmieniam IS5 na ACTIVE")
        self.waitMsec(500)
        startup_sensor_1.setState(ACTIVE) # IS5 - Pociag osobowy 
        self.waitMsec(500)
        startup_sensor_1.setState(ACTIVE) # IS5 - Pociag osobowy - podwojne zastosowanie
        train_initial_station_func()
        self.waitMsec(500)
        print("Zmieniam IS6 na ACTIVE") #IS6 - Pociag towarowy
        self.waitMsec(500)
        startup_sensor_2.setState(ACTIVE)
        self.waitMsec(500)
        return 0


Lok2EndDay().start()

