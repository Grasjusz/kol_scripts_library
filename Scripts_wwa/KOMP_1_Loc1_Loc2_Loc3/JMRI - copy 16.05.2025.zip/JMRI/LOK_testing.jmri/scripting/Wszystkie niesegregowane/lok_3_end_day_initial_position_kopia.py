import jarray
import jmri
import sys
import os

# -*- coding: utf-8 -*-

# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py (ustawiony glowny katalog skryptow)
sys.path.append(os.path.join(sys.path[0]))
import Kollib #Biblioteka autorskich funkcji

# Pobierz sensory startowe
startup_sensor_1 = sensors.getSensor("IS3")  # Pozycja startowa tramwaj wisla

# Sensory wisla
LS33 = sensors.getSensor("LS33") #Czujnik 0 Lista 1 
LS34 = sensors.getSensor("LS34") #Czujnik 1 Lista 1
LS35 = sensors.getSensor("LS35") #Czujnik 2 Lista 1
LS36 = sensors.getSensor("LS36") #Czujnik 3 Lista 1
LS37 = sensors.getSensor("LS37") #Czujnik 4 Lista 1
LS38 = sensors.getSensor("LS38") #Czujnik 5 Lista 1
LS39 = sensors.getSensor("LS39") #Czujnik 6 Lista 1
LS40 = sensors.getSensor("LS40") #Czujnik 7 Lista 1
LS41 = sensors.getSensor("LS41") #Czujnik 8 Lista 1
LS42 = sensors.getSensor("LS42") #Czujnik 9 Lista 1
LS43 = sensors.getSensor("LS43") #Czujnik 10 Lista 1


#Czy modul zwrotnic dziala i nie resetuje sie? - wylaczamy sprawdzanie zwrotnic DO PRZEROBIENIA DO PRZEROBIENIA JAK W LOK2

"""FirstTurnoutAdress = 104
NumberOfTurnouts = 2
TurnoutsList_BCD = []
for i in range(FirstTurnoutAdress, FirstTurnoutAdress + NumberOfTurnouts):
    TurnoutsList_BCD.append(turnouts.getTurnout("LT"+str(i)))"""
#print("Turnout List 1:", TurnoutsList_BCD)


class Lok3EndDay(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.
        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(11, False)  # Tramwaj


    def handle(self):
        # handle() is called repeatedly until it returns false.
        print("LOK3 funkcja awaryjna, ustawiam pociagi na pozycje startowe")
        self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
        speed_global = 0.3 # Ustawiamy jedną zmienna główną prędkosc

        #Wylaczam sprawdzanie zwrotnic - modul nie dziala
        """
        def turnouts_initial_positions():
            #Sprawdz czy zwrotnice sa w odpowiednim polozeniu i ustaw na pozycje startowe
            # 2 dla CLOSED, 4 dla THROW
            
            if TurnoutsList_BCD[0].getKnownState() == 2:
                TurnoutsList_BCD[0].setState(4)
                self.waitMsec(1000)
                print("LOK3 Przestawiam zwrotnice na THROWN:", TurnoutsList_BCD[0], TurnoutsList_BCD[0].getKnownState())

            elif TurnoutsList_BCD[1].getKnownState() == 2:
                TurnoutsList_BCD[1].setState(4)
                self.waitMsec(1000)
                print("LOK3 Przestawiam zwrotnice na THROWN:", TurnoutsList_BCD[1], TurnoutsList_BCD[1].getKnownState())

            else:
                TurnoutsList_BCD[0].setState(4)
                self.waitMsec(1000)
                print("LOK3 Przestawiam zwrotnice na THROWN:", TurnoutsList_BCD[0], TurnoutsList_BCD[0].getKnownState())
                TurnoutsList_BCD[1].setState(4)
                self.waitMsec(1000)
                print("LOK3 Przestawiam zwrotnice na THROWN:", TurnoutsList_BCD[1], TurnoutsList_BCD[1].getKnownState())
            return 0
        """

        def make_noise_train():
            self.throttle1.setF1(False)  # wylacz dzwiek silnika
            self.throttle1.setF0(False)  # zgas światła
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(100)
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(100)
            self.throttle1.setF2(True)  # run make some noise
            self.waitMsec(2000)
            self.throttle1.setF2(False)  # end make some noise
            self.waitMsec(3000)
            return


        """Funkcja uruchomieniowa - awaryjny dojazd do stacji startowej jezeli pociag na niej sie nie znajduje
        co okolo sekunde uzywa sygnalu dziekowego - jezeli na niej sie znajduje - trabi 3 razy po 2 sekundy"""
        def drive_to_start_station_tram():
            print("LOK3 Pociag uruchamiam funkcje powrotu na stacje poczatkowe")
            self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
            self.waitMsec(1000)
            if LS34.state != ACTIVE:
                Kollib.drive_vehicle(self, self.throttle1, speed_global, False) # Rusza do tylu by wzbudzic pierwszy czujnik
                while LS34.state != ACTIVE:
                    self.waitMsec(100)
                    self.throttle1.setF0(True)  # wlacz mruganie swiatlami
                    self.waitMsec(1000)
                    self.throttle1.setF0(False)  # wylacz mruganie swiatlami
                    self.waitMsec(100)
                    if LS34.state == ACTIVE:
                        Kollib.drive_vehicle(self, self.throttle1, 0.0,False)
                        print("LOK3 Pociag dojechal na stacje startowa - koniec petli")
                        return

        #Funkcja wywolujaca funkcje w zaleznosci na jakim czujniku znajduje sie pociag
        def tram_initial_station_func():
            #Petla odpalajaca powrot do stacji startowej tramwaj - nie widzi nigdzie pociagu
            if LS33.state != ACTIVE and LS34.state != ACTIVE and LS42.state != ACTIVE:
                print("LOK3 Pociag nie widzi pociagu na zadnych czujkach - uruchamiam funkcje powrotu na stacje poczatkowe")
                # turnouts_initial_positions() - wylaczamy tymaczsowe sprawdzanie zwrotnic
                drive_to_start_station_tram() # uruchom program powracajacy na stacje startowe
                Kollib.drive_vehicle(self, self.throttle1, 0.0, False)
                print("LOK3 pociag DOJECHAL do stacji startowej - Koncze skrypt")
                make_noise_train() # sygnal dzwiekowy wskazujacy dojazd a stacje poczatkowa
                return
            
            # Pociag stoi za daleko na czujniku 0 - jedzie do przodu po czym uruchamia funkcje powrotu na stacje startowe
            elif LS33.state == ACTIVE and LS42.state != ACTIVE:
                print("LOK3 Pociag pojechal za daleko SPRAWDZ CZY NIE SPADL Z TOROW - uruchamiam funkcje powrotu na stacje poczatkowe")
                # turnouts_initial_positions() - wylaczamy tymaczsowe sprawdzanie zwrotnic
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True) # Rusza do przodu by wzbudzic pierwszy czujnik i nie zjechac za daleko
                self.waitMsec(6000)
                drive_to_start_station_tram() # uruchom program powracajacy na stacje startowe
                Kollib.drive_vehicle(self, self.throttle1, 0.0, False)
                print("LOK3 pociag DOJECHAL do stacji startowej - Koncze skrypt")
                make_noise_train() # sygnal dzwiekowy wskazujacy dojazd a stacje poczatkowa
                return           
            
            # Pociag stoi na czujniku 1 - stoi na stacji startowej
            elif LS33.state != ACTIVE and LS34.state == ACTIVE and LS42.state != ACTIVE:
                # turnouts_initial_positions() - wylaczamy tymaczsowe sprawdzanie zwrotnic
                Kollib.drive_vehicle(self, self.throttle1, 0.0, False)
                print("LOK3 Pociag STOI na stacje startowa - koniec petli")
                return

        tram_initial_station_func()
        print("Zmieniam IS3 na ACTIVE")
        self.waitMsec(500)
        startup_sensor_1.setState(ACTIVE)
        self.waitMsec(500)
        return 0


Lok3EndDay().start()

