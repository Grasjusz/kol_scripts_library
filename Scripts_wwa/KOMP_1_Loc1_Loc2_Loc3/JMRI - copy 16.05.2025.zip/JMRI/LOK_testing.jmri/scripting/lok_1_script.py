import jarray
import jmri
import sys 
import os

# -*- coding: utf-8 -*-

# Dodaj ścieżke do katalogu, w którym znajduje sie biblioteka Kollib.py (ustawiony glowny katalog skryptow)
sys.path.append(os.path.join(sys.path[0])) #szuka biblioteczki w tym samym folderze w ktorym jest uruchamiany skrypt
import Kollib #Biblioteka autorskich funkcji

# Definiowanie poszczególnych elementów ścieżki do pliku - w celu dostosowania pod wlasne potrzeby
user_folder = "C:\\Users\\LOK_1"
jmri_folder = "JMRI"
file_name_LOK_1 = "lok_1_end_day_initial_position.py"  # nazwa pliku do otwarcia

# Tworzenie pełnej ścieżki za pomocą os.path.join
file_path_LOK_1_emergency = os.path.join(user_folder, jmri_folder, "LOK_testing.jmri", "scripting", file_name_LOK_1)

#Sensory tramwaj burza
LS1 = sensors.getSensor("LS1") #Czujnik 0 Lista 1 
LS2 = sensors.getSensor("LS2") #Czujnik 1 Lista 1 
LS3 = sensors.getSensor("LS3") #Czujnik 2 Lista 1 
LS4 = sensors.getSensor("LS4") #Czujnik 3 Lista 1 
LS5 = sensors.getSensor("LS5") #Czujnik 4 Lista 1 
LS6 = sensors.getSensor("LS6") #Czujnik 5 Lista 1 
LS7 = sensors.getSensor("LS7") #Czujnik 6 Lista 1 
#print("LOK1 Sensor tramwaj burza: ", LS1, LS2, LS3, LS4, LS5, LS6, LS7)


class Lok1(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):
        # init() is called exactly once at the beginning to do
        # any necessary configuration.
        
        # Sensor sprzezony z startup_script - uruchamiajacy makiete - pierwsze uruchomienie
        sensor_lok_1 = sensors.getSensor("IS102")
        self.waitSensorActive(sensor_lok_1)

        print("LOK1 Program tramwaj burza uruchomiony...  Czekam na sensor IS1.. ze skryptu startup..")

        # Uruchomienie pliku na stacje startowe
        exec(open(file_path_LOK_1_emergency).read(), globals())

        #Sensor wirtualny sprawdzający stacje poczatkowa
        self.startup_sensor = sensors.getSensor("IS1")  # Pozycja startowa tramwaj burza
        self.waitSensorActive(self.startup_sensor)

        # get loco address. For long address change "False" to "True"
        self.throttle1 = self.getThrottle(10, False) #Tramwaj burza
        return

    def handle(self):
        # handle() is called repeatedly until it returns false.
        print("LOK1 Program LOK1_HANDLE uruchomiony")

        speed_global = 0.4 # Ustawiamy jedną zmienna glowna prędkosc

        while True:
            def check_stop():
                """Sensor wirtualny zatrzymujacy lub uruchamiajacy z powrotem makiete"""
                self.startup_sensor = sensors.getSensor("IS1")  # Pozycja startowa tramwaj burza
                suspend = self.waitSensorActive(self.startup_sensor)

                if suspend == ACTIVE:
                    pass
                elif suspend != ACTIVE:
                    print("LOK1 Pociagi zatrzymane LOK_1_burza")
                    Kollib.drive_vehicle(self, self.throttle1, 0, True)
                    print("LOK1 Pauza wlaczona..")
                return
            
            def signal_before_start():
                """Sygnal przed uruchomieniem pociagu"""
                self.throttle1.setF4(True)  # Wlacz dzwonek przed ruszeniem
                self.waitMsec(100)
                self.throttle1.setF4(False)  # Wylacz dzwonek przed ruszeniem
                self.waitMsec(4000)
                self.throttle1.setF2(True)  # Wlacz trabnij przed ruszeniem
                self.waitMsec(1000)
                self.throttle1.setF2(False)  # Wylacz trabnij przed ruszeniem
                self.waitMsec(100)
                return
            
            def crossing_honk():
                self.throttle1.setF2(True)  # Wlacz trabnij przed przejsciem
                self.waitMsec(1500)
                self.throttle1.setF2(False)  # Wylacz trabnij przed przejsciem
                return

            def driving_loop():
                """Jedzie do przodu - wozek napedowy z przodu"""
                #print("STATE: ", LS1.state)
                print("LOK1 PETLA URUCHOMIONA")
                self.throttle1.setSpeedSetting(0)  # Upewnia sie że kolejka jest zatrzymana
                self.waitMsec(1000)
                #print("Czujnik zajety: ", LS1)
                self.waitMsec(100)
                print("LOK1 Sprawdzam czy TRAMWAJ na stacji STARTOWEJ...")
                self.waitSensorActive(LS1)
                print("LOK1 Zatrzymanie na stacji 1 - LOK1")
                self.waitMsec(100)
                self.throttle1.setF1(False)  # wylacz dzwiek silnika
                self.waitMsec(6000)
                print("LOK1 Start ze stacji 1 - LOK1")
                self.throttle1.setF1(True)  # wlacz dzwiek silnika
                self.waitMsec(6000)
                self.throttle1.setF0(True)  # Zapal światła
                self.waitMsec(100)
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True)
                self.waitMsec(100)
                signal_before_start()  # funkcja dekoracyjna sygnal przed uruchomieniem pociagu
                self.waitMsec(100)
                self.waitSensorActive(LS2)
                #print("Czujnik zajety: ", LS2)
                self.waitMsec(100)
                print("LOK1 Zatrzymanie na stacji 2 - LOK1")
                Kollib.delay_stop(self, self.throttle1, LS2, 100)
                Kollib.stop_at_station(self, self.throttle1, LS2, 6000)
                print("LOK1 Start ze stacji 2 - LOK1")
                self.waitMsec(100)
                signal_before_start()  # funkcja dekoracyjna sygnal przed uruchomieniem pociagu
                self.waitMsec(100)
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True)

                self.waitSensorActive(LS3)
                #print("Czujnik zajety: ", LS3)
                self.waitMsec(100)
                print("LOK1 Zatrzymanie na stacji 3 - LOK1")
                Kollib.delay_stop(self, self.throttle1, LS3, 100)
                Kollib.stop_at_station(self, self.throttle1, LS3, 6000)
                print("LOK1 Start ze stacji 3 - LOK1")
                self.waitMsec(100)
                signal_before_start()  # funkcja dekoracyjna sygnal przed uruchomieniem pociagu
                self.waitMsec(100)
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True)

                self.waitSensorActive(LS4)
                #print("Czujnik zajety: ", LS4)
                self.waitMsec(100)
                print("LOK1 Przejscie dla pieszych - LOK1")
                crossing_honk() # funkcja dekoracyjna sygnal przed przejsciem dla pieszych
                self.waitMsec(100)
                Kollib.speed_change(self, self.throttle1, 0.7)
                self.waitMsec(3000)
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True)

                self.waitSensorActive(LS5)
                #print("Czujnik zajety: ", LS5)
                self.waitMsec(100)
                print("LOK1 Przejscie dla pieszych - LOK1")
                self.throttle1.setF2(True)  # Wlacz trabnij przed przejsciem
                self.waitMsec(1500)
                self.throttle1.setF2(False)  # Wylacz trabnij przed przejsciem
                self.waitMsec(100)
                Kollib.speed_change(self, self.throttle1, 0.7)
                self.waitMsec(3000)
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True)

                self.waitSensorActive(LS6)
                #print("Czujnik zajety: ", LS6)
                self.waitMsec(100)
                print("LOK1 Skrzyżowanie - LOK1")
                Kollib.speed_change(self, self.throttle1, 0.7)
                self.throttle1.setF2(True)  # Wlacz trabnij przed przejsciem
                self.waitMsec(1000)
                self.throttle1.setF2(False)  # Wylacz trabnij przed przejsciem
                self.waitMsec(100)
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True)

                self.waitSensorActive(LS7)
                #print("Czujnik zajety: ", LS7)
                self.waitMsec(100)
                print("LOK1 Zatrzymanie na stacji 4 - LOK1")
                Kollib.delay_stop(self, self.throttle1, LS7, 100)
                Kollib.stop_at_station(self, self.throttle1, LS7, 6000)
                print("LOK1 Start ze stacji 4 - LOK1")
                self.waitMsec(100)
                signal_before_start()  # funkcja dekoracyjna sygnal przed uruchomieniem pociagu
                self.waitMsec(100)
                Kollib.drive_vehicle(self, self.throttle1, speed_global, True)
                self.waitMsec(5000)
                Kollib.speed_change(self, self.throttle1, 0.7)

                self.waitSensorActive(LS1)
                #print("Czujnik zajety: ", LS1)
                self.waitMsec(100)
                print("LOK1 Zatrzymanie na stacji 1 - koniec petli")
                Kollib.delay_stop(self, self.throttle1, LS1, 500)
                self.waitMsec(100)
                self.throttle1.setF1(False)  # wylacz dzwiek silnika
                self.waitMsec(6000)
                print("LOK1 KONIEC PETLI, ROZPOCZYNAM NOWA LOK_1_BURZA")
                return

            check_stop()
            driving_loop()


Lok1().start()

