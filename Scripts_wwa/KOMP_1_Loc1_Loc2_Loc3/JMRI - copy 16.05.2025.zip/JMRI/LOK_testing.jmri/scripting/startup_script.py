import jarray
import jmri
import os
# -*- coding: utf-8 -*-


class Start(jmri.jmrit.automat.AbstractAutomaton):

    def init(self):

        #Resetuje zasilanie jesli wlaczone, jesli nie, uruchamia i daje czas na realizacje czujnikow
        print("Uruchamiam zasilanie...")
        powermanager.setPower(jmri.PowerManager.OFF)
        self.waitMsec(3000)
        powermanager.setPower(jmri.PowerManager.IDLE)
        self.waitMsec(3000)
        powermanager.setPower(jmri.PowerManager.ON)
        self.waitMsec(5000)

        print("Uruchamiam makiete.. Czekaj..")
        # Initializuje wirtualne czujniki "switche on/off do uruchamiania skryptu wlasciwego"
        self.sensor_lok_1 = sensors.getSensor("IS102")
        self.sensor_lok_2 = sensors.getSensor("IS100")
        self.sensor_lok_3 = sensors.getSensor("IS101")



        #Initializuje lokomotywy
        self.tram_storm = self.getThrottle(10, False)  # tramwaj burza adr 10
        self.tram_visla = self.getThrottle(11, False)  # tramwaj wisla adr 11
        self.tram_visla_bridge = self.getThrottle(12, False)  # tramwaj most1 wisla adr 12
        self.tram_visla_bridge_2 = self.getThrottle(13, False)  # tramwaj most2 wisla adr 13
        self.train_long = self.getThrottle(3, False)  # pociag osobowy adr 3
        self.br80 = self.getThrottle(5, False)  # BR80 adr 5
        self.V20 = self.getThrottle(6, False)  # V20020 adr 6
        return


    def handle(self):

        # Zatrzymuje pociagi jesli jakis sie zawiesil
        print("Zatrzymanie pociagow przed uruchomieniem")

        self.tram_storm.setSpeedSetting(0) #tramwaj burza
        self.waitMsec(100)

        self.V20.setSpeedSetting(0) #v20 wilenska
        self.waitMsec(100)

        self.train_long.setSpeedSetting(0) #pociag osobowy wilenska
        self.waitMsec(100)

        self.tram_visla.setSpeedSetting(0) #tramwaj wisla
        self.waitMsec(100)

        #Wylaczone kolejki ktore maja byc -  przygotwane pod trasy mostowe
        """

        self.tram_visla_bridge.setSpeedSetting(0)
        self.waitMsec(100)

        self.tram_visla_bridge_2.setSpeedSetting(0)
        self.waitMsec(100)
        
        self.br80.setSpeedSetting(0)
        self.waitMsec(100)
        """

        # Wlaczanie sensorow startup
        print("STARTUP Uruchamiam LOK_1")
        self.sensor_lok_1.setState(ACTIVE)
        self.waitMsec(5000)
        print("STARTUP Uruchamiam LOK_2")
        self.sensor_lok_2.setState(ACTIVE)
        self.waitMsec(5000)
        print("STARTUP Uruchamiam LOK_3")
        self.sensor_lok_3.setState(ACTIVE)
        return


Start().start()
