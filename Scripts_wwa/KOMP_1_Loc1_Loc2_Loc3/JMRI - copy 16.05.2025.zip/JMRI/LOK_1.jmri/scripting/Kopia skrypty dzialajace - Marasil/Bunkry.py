import jarray
import jmri
import sys

# Dodaj ścieżkę do katalogu, w którym znajduje się biblioteka Kollib.py
sys.path.append(r'C:\Users\LOK_7\JMRI\My_JMRI_Railroad.jmri\MyScrypt')
import Kollib  # Biblioteka autorskich funkcji

# Sekwencyjne przypisywanie adresów sensorą
FirstSensorAdress = 1
NumberOfSensors = 32
SensorsList2 = []
SensorsList2.append(0)
for i in range(FirstSensorAdress, FirstSensorAdress + NumberOfSensors):
    SensorsList2.append(sensors.getSensor("LS" + str(i)))
print(SensorsList2)

START_SIGNAL = sensors.getSensor("IS333")
START_SIGNAL.setKnownState(4)
"""NA_STACJI_MOST = sensors.getSensor("IS334")
NA_STACJI_KOLEJ = sensors.getSensor("IS335")"""

FirstTurnoutAdress = 100
NumberOfTurnouts = 4
TurnoutsList2= []
TurnoutsList2.append(0)
for i in range(FirstTurnoutAdress, FirstTurnoutAdress + NumberOfTurnouts):
    TurnoutsList2.append(turnouts.getTurnout("LT" + str(i)))  # Tworzenie adresu zwrotnicy np. LT1, LT2...
print(TurnoutsList2)  # Drukowanie listy zwrotnic do sprawdzenia

'''
Jeśli czujniki nie są ułożone w sekwencji, możesz dodać je jako Sensor1 = sensors.getSensor("LS1") lub
SensorsList2.append(sensors.getSensor("LS" + str(1))), jeśli chcesz umieścić je w liście.
Jeśli to możliwe, dopisz taki sam algorytm dla innych elementów.
Jeśli dany sensor nie znajduje się na liście sensorów w panelu "PanelPro" 
(jego wartość to None), skutkuje to wyłaczeniem watku w którym znajduje sie fukcja
odnoszaca sie do tego czujnika.
'''
class Lok2(jmri.jmrit.automat.AbstractAutomaton):
    def init(self):
        print("LOK2 init")
        self.lokomotywa_1 = self.getThrottle(3, False)  # Pociag osobowy
        self.lokomotywa_2 = self.getThrottle(6, False)  # V20, towarowy
        self.i = True
        return
    def handle(self):
        print("LOK2 handle")
        self.lokomotywa_1.setSpeedSetting(0)
        self.lokomotywa_2.setSpeedSetting(0)
        print("Wait for sensor start",self, "START_SIGNAL state:", START_SIGNAL.getKnownState())
        if START_SIGNAL.getKnownState() != 2:
            self.lokomotywa_1.setSpeedSetting(0)
            self.lokomotywa_1.setF0(False)
            self.lokomotywa_1.setF1(False)
            self.lokomotywa_1.setF3(True)
            self.lokomotywa_2.setSpeedSetting(0)
            self.lokomotywa_2.setF0(False)
            self.lokomotywa_2.setF1(False)
            self.lokomotywa_2.setF3(True)
        self.waitSensorActive([START_SIGNAL])
        print("start")


        while self.i:
            Kollib.drive_vehicle(self, self.lokomotywa_2, 0.1, False)
            self.waitMsec(50)
            Kollib.drive_vehicle(self, self.lokomotywa_2, 0.1, True)
            self.waitMsec(50)
            Kollib.drive_vehicle(self, self.lokomotywa_2, 0.1, False)
            self.waitMsec(50)
            Kollib.drive_vehicle(self, self.lokomotywa_2, 0, True)
            self.waitMsec(50)
            print("Sensor 30:", SensorsList2[30].getKnownState(), "Sensor 31:", SensorsList2[31].getKnownState())
            TurnoutsList2[2].setState(4)
            if SensorsList2[30].getKnownState() != 2 and SensorsList2[31].getKnownState() != 2:
                self.lokomotywa_2.setF0(True)
                self.lokomotywa_2.setF1(True)
                Kollib.drive_vehicle(self, self.lokomotywa_2, 0.30, True)
                Kollib.stop_at_station(self, self.lokomotywa_2, SensorsList2[31], 2000)
            else:
                self.lokomotywa_2.setSpeedSetting(0)
                print("tramwaj_2 na stacji")
            Kollib.drive_vehicle(self, self.lokomotywa_1, 0.1, True)
            self.waitMsec(50)
            Kollib.drive_vehicle(self, self.lokomotywa_1, 0.1, False)
            self.waitMsec(50)
            Kollib.drive_vehicle(self, self.lokomotywa_1, 0.1, True)
            self.waitMsec(50)
            Kollib.drive_vehicle(self, self.lokomotywa_1, 0, False)
            self.waitMsec(50)
            print("Sensor 17:", SensorsList2[17].getKnownState(), "Sensor 18:", SensorsList2[18].getKnownState())
            if SensorsList2[17].getKnownState() != 2 and SensorsList2[18].getKnownState() != 2:
                self.lokomotywa_1.setF0(True)
                self.lokomotywa_1.setF6(True)
                Kollib.drive_vehicle(self, self.lokomotywa_1, 0.30, True)
                Kollib.stop_at_station(self, self.lokomotywa_1, SensorsList2[17], 2000)
                self.i = False
            else:
                self.lokomotywa_2.setSpeedSetting(0)
                print("tramwaj_2 na stacji")
                self.i = False

        Kollib.drive_vehicle(self,self.lokomotywa_1,0.5,False)
        TurnoutsList2[3].setState(4)
        self.waitSensorActive(SensorsList2[19])

        Kollib.drive_vehicle(self,self.lokomotywa_2,0.3,False)
        Kollib.drive_vehicle(self,self.lokomotywa_1,0.4,False)

        Kollib.delay_stop(self,self.lokomotywa_1,SensorsList2[20],5000)
        Kollib.delay_stop(self,self.lokomotywa_2,SensorsList2[27],3000)

        Kollib.drive_vehicle(self, self.lokomotywa_1, 0.5, True)
        TurnoutsList2[4].setState(4)
        Kollib.stop_at_station(self, self.lokomotywa_1, SensorsList2[19], 1000)

        Kollib.drive_vehicle(self, self.lokomotywa_2, 0.3, True)
        TurnoutsList2[2].setState(4)
        self.waitSensorActive(SensorsList2[28])
        Kollib.drive_vehicle(self, self.lokomotywa_1, 0.5, True)
        self.waitSensorActive(SensorsList2[18])
        self.lokomotywa_1.setSpeedSetting(0.1)
        Kollib.stop_at_station(self, self.lokomotywa_1, SensorsList2[17],0)
        Kollib.stop_at_station(self, self.lokomotywa_2, SensorsList2[31],0)
        return 1
Lok2().start()